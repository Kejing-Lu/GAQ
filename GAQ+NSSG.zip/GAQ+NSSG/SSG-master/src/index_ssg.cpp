#include "index_ssg.h"

#include <omp.h>
#include <bitset>
#include <chrono>
#include <cmath>
#include <queue>
#include <boost/dynamic_bitset.hpp>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/imgproc/imgproc.hpp"


#include "exceptions.h"
#include "parameters.h"

constexpr double kPi = 3.14159265358979323846264;

using namespace cv;

namespace efanna2e {

IndexSSG::IndexSSG(const size_t dimension, const size_t n, Metric m,
                   Index *initializer)
    : Index(dimension, n, m), initializer_{initializer} {}

IndexSSG::~IndexSSG() {}

 float compare00(const float *a, const float *b, unsigned size){
    float result = 0;
	
#ifdef __GNUC__
#ifdef __AVX__
#define AVX_DOT(addr1, addr2, dest, tmp1, tmp2) \
  tmp1 = _mm256_loadu_ps(addr1);                \
  tmp2 = _mm256_loadu_ps(addr2);                \
  tmp1 = _mm256_mul_ps(tmp1, tmp2);             \
  dest = _mm256_add_ps(dest, tmp1);

    __m256 sum;
    __m256 l0, l1;
    __m256 r0, r1;
    unsigned D = (size + 7) & ~7U;
    unsigned DR = D % 16;
    unsigned DD = D - DR;
    const float *l = a;
    const float *r = b;
    const float *e_l = l + DD;
    const float *e_r = r + DD;
    float unpack[8] __attribute__((aligned(32))) = {0, 0, 0, 0, 0, 0, 0, 0};

    sum = _mm256_loadu_ps(unpack);
    if (DR) {
      AVX_DOT(e_l, e_r, sum, l0, r0);
    }

    for (unsigned i = 0; i < DD; i += 16, l += 16, r += 16) {
      AVX_DOT(l, r, sum, l0, r0);
      AVX_DOT(l + 8, r + 8, sum, l1, r1);
    }
    _mm256_storeu_ps(unpack, sum);
    result = unpack[0] + unpack[1] + unpack[2] + unpack[3] + unpack[4] +
             unpack[5] + unpack[6] + unpack[7];

#else
#ifdef __SSE2__
#define SSE_DOT(addr1, addr2, dest, tmp1, tmp2) \
  tmp1 = _mm_loadu_ps(addr1);                \
  tmp2 = _mm_loadu_ps(addr2);                \
  tmp1 = _mm_mul_ps(tmp1, tmp2);             \
  dest = _mm_add_ps(dest, tmp1);
    __m128 sum;
    __m128 l0, l1, l2, l3;
    __m128 r0, r1, r2, r3;
    unsigned D = (size + 3) & ~3U;
    unsigned DR = D % 16;
    unsigned DD = D - DR;
    const float *l = a;
    const float *r = b;
    const float *e_l = l + DD;
    const float *e_r = r + DD;
    float unpack[4] __attribute__((aligned(16))) = {0, 0, 0, 0};

    sum = _mm_load_ps(unpack);
    switch (DR) {
      case 12:
        SSE_DOT(e_l + 8, e_r + 8, sum, l2, r2);
      case 8:
        SSE_DOT(e_l + 4, e_r + 4, sum, l1, r1);
      case 4:
        SSE_DOT(e_l, e_r, sum, l0, r0);
      default:
        break;
    }
    for (unsigned i = 0; i < DD; i += 16, l += 16, r += 16) {
      SSE_DOT(l, r, sum, l0, r0);
      SSE_DOT(l + 4, r + 4, sum, l1, r1);
      SSE_DOT(l + 8, r + 8, sum, l2, r2);
      SSE_DOT(l + 12, r + 12, sum, l3, r3);
    }
    _mm_storeu_ps(unpack, sum);
    result += unpack[0] + unpack[1] + unpack[2] + unpack[3];
#else

    float dot0, dot1, dot2, dot3;
    const float* last = a + size;
    const float* unroll_group = last - 3;

    // Process 4 items with each loop for efficiency.

    while (a < unroll_group) {
      dot0 = a[0] * b[0];
      dot1 = a[1] * b[1];
      dot2 = a[2] * b[2];
      dot3 = a[3] * b[3];
      result += dot0 + dot1 + dot2 + dot3;
      a += 4;
      b += 4;
    }
    /* Process last 0-3 pixels.  Not needed for standard vector lengths. */
    while (a < last) {
      result += *a++ * *b++;
    }
#endif
#endif
#endif
    return result;
  }

void IndexSSG::Save(const char *filename) {
  std::ofstream out(filename, std::ios::binary | std::ios::out);
  assert(final_graph_.size() == nd_);

  out.write((char *)&width, sizeof(unsigned));
  unsigned n_ep=eps_.size();
  out.write((char *)&n_ep, sizeof(unsigned));
  out.write((char *)eps_.data(), n_ep*sizeof(unsigned));
  for (unsigned i = 0; i < nd_; i++) {
    unsigned GK = (unsigned)final_graph_[i].size();
    out.write((char *)&GK, sizeof(unsigned));
    out.write((char *)final_graph_[i].data(), GK * sizeof(unsigned));
  }
  out.close();
}

void IndexSSG::Load(const char *filename) {
  std::ifstream in(filename, std::ios::binary);
  in.read((char *)&width, sizeof(unsigned));
  unsigned n_ep=0;
  in.read((char *)&n_ep, sizeof(unsigned));
  eps_.resize(n_ep);
  in.read((char *)eps_.data(), n_ep*sizeof(unsigned));
  
  unsigned cc = 0;
  while (!in.eof()) {
    unsigned k;
    in.read((char *)&k, sizeof(unsigned));
    if (in.eof()) break;
    cc += k;
    std::vector<unsigned> tmp(k);
    in.read((char *)tmp.data(), k * sizeof(unsigned));
    final_graph_.push_back(tmp);
  }
  cc /= nd_;
  std::cerr << "Average Degree = " << cc << std::endl;
}

void IndexSSG::Load_nn_graph(const char *filename) {
  std::ifstream in(filename, std::ios::binary);
  unsigned k;
  in.read((char *)&k, sizeof(unsigned));
  
  k = KK;
  in.seekg(0, std::ios::end);
  std::ios::pos_type ss = in.tellg();
  size_t fsize = (size_t)ss;
  size_t num = (unsigned)(fsize / (k + 1) / 4);
  in.seekg(0, std::ios::beg);

  final_graph_.resize(num);
  final_graph_.reserve(num);
  unsigned kk = (k + 3) / 4 * 4;
  for (size_t i = 0; i < num; i++) {
    in.seekg(4, std::ios::cur);
    final_graph_[i].resize(k);
    final_graph_[i].reserve(kk);
    in.read((char *)final_graph_[i].data(), k * sizeof(unsigned));
  }
  in.close();
}

void IndexSSG::get_neighbors(const unsigned q, const Parameters &parameter,
                             std::vector<Neighbor> &pool) {
  boost::dynamic_bitset<> flags{nd_, 0};
  unsigned L = parameter.Get<unsigned>("L");
  flags[q] = true;
  for (unsigned i = 0; i < final_graph_[q].size(); i++) {
    unsigned nid = final_graph_[q][i];
    for (unsigned nn = 0; nn < final_graph_[nid].size(); nn++) {
      unsigned nnid = final_graph_[nid][nn];
      if (flags[nnid]) continue;
      flags[nnid] = true;
      float dist = distance_->compare(data_ + dimension_ * q,
                                      data_ + dimension_ * nnid, dimension_);
      pool.push_back(Neighbor(nnid, dist, true));
      if (pool.size() >= L) break;
    }
    if (pool.size() >= L) break;
  }
}

void IndexSSG::get_neighbors(const float *query, const Parameters &parameter,
                             std::vector<Neighbor> &retset,
                             std::vector<Neighbor> &fullset) {
  unsigned L = parameter.Get<unsigned>("L");

  retset.resize(L + 1);
  std::vector<unsigned> init_ids(L);

  std::mt19937 rng(rand());
  GenRandom(rng, init_ids.data(), L, (unsigned)nd_);

  boost::dynamic_bitset<> flags{nd_, 0};
  L = 0;
  for (unsigned i = 0; i < init_ids.size(); i++) {
    unsigned id = init_ids[i];
    if (id >= nd_) continue;
    float dist = distance_->compare(data_ + dimension_ * (size_t)id, query,
                                    (unsigned)dimension_);
    retset[i] = Neighbor(id, dist, true);
    flags[id] = 1;
    L++;
  }

  std::sort(retset.begin(), retset.begin() + L);
  int k = 0;
  while (k < (int)L) {
    int nk = L;

    if (retset[k].flag) {
      retset[k].flag = false;
      unsigned n = retset[k].id;

      for (unsigned m = 0; m < final_graph_[n].size(); ++m) {
        unsigned id = final_graph_[n][m];

        if (flags[id]) continue;
        flags[id] = 1;

        float dist = distance_->compare(query, data_ + dimension_ * (size_t)id,
                                        (unsigned)dimension_);

        Neighbor nn(id, dist, true);
        fullset.push_back(nn);
        if (dist >= retset[L - 1].distance) continue;
        int r = InsertIntoPool(retset.data(), L, nn);

        if (L + 1 < retset.size()) ++L;
        if (r < nk) nk = r;
      }
    }
    if (nk <= k)
      k = nk;
    else
      ++k;
  }
}

void IndexSSG::init_graph(const Parameters &parameters) {
  float *center = new float[dimension_];
  for (unsigned j = 0; j < dimension_; j++) center[j] = 0;
  for (unsigned i = 0; i < nd_; i++) {
    for (unsigned j = 0; j < dimension_; j++) {
      center[j] += data_[i * dimension_ + j];
    }
  }
  for (unsigned j = 0; j < dimension_; j++) {
    center[j] /= nd_;
  }
  std::vector<Neighbor> tmp, pool;
   ep_ = rand() % nd_;  // random initialize navigating point
  get_neighbors(center, parameters, tmp, pool);
  ep_ = tmp[0].id;  // For Compatibility
}

void IndexSSG::sync_prune(unsigned q, std::vector<Neighbor> &pool,
                          const Parameters &parameters, float threshold,
                          SimpleNeighbor *cut_graph_) {
  unsigned range = parameters.Get<unsigned>("R");
  width = range;
  unsigned start = 0;

  boost::dynamic_bitset<> flags{nd_, 0};
  for (unsigned i = 0; i < pool.size(); ++i) {
    flags[pool[i].id] = 1;
  }
  for (unsigned nn = 0; nn < final_graph_[q].size(); nn++) {
    unsigned id = final_graph_[q][nn];
    if (flags[id]) continue;
    float dist = distance_->compare(data_ + dimension_ * (size_t)q,
                                    data_ + dimension_ * (size_t)id,
                                    (unsigned)dimension_);
    pool.push_back(Neighbor(id, dist, true));
  }

  std::sort(pool.begin(), pool.end());
  std::vector<Neighbor> result;
  if (pool[start].id == q) start++;
  result.push_back(pool[start]);

  while (result.size() < range && (++start) < pool.size()) {
    auto &p = pool[start];
    bool occlude = false;
    for (unsigned t = 0; t < result.size(); t++) {
      if (p.id == result[t].id) {
        occlude = true;
        break;
      }
      float djk = distance_->compare(data_ + dimension_ * (size_t)result[t].id,
                                     data_ + dimension_ * (size_t)p.id,
                                     (unsigned)dimension_);
      float cos_ij = (p.distance + result[t].distance - djk) / 2 /
                     sqrt(p.distance * result[t].distance);
      if (cos_ij > threshold) {
        occlude = true;
        break;
      }
    }
    if (!occlude) result.push_back(p);
  }

  SimpleNeighbor *des_pool = cut_graph_ + (size_t)q * (size_t)range;
  for (size_t t = 0; t < result.size(); t++) {
    des_pool[t].id = result[t].id;
    des_pool[t].distance = result[t].distance;
  }
  if (result.size() < range) {
    des_pool[result.size()].distance = -1;
  }
}

void IndexSSG::InterInsert(unsigned n, unsigned range, float threshold,
                           std::vector<std::mutex> &locks,
                           SimpleNeighbor *cut_graph_) {
  SimpleNeighbor *src_pool = cut_graph_ + (size_t)n * (size_t)range;
  for (size_t i = 0; i < range; i++) {
    if (src_pool[i].distance == -1) break;

    SimpleNeighbor sn(n, src_pool[i].distance);
    size_t des = src_pool[i].id;
    SimpleNeighbor *des_pool = cut_graph_ + des * (size_t)range;

    std::vector<SimpleNeighbor> temp_pool;
    int dup = 0;
    {
      LockGuard guard(locks[des]);
      for (size_t j = 0; j < range; j++) {
        if (des_pool[j].distance == -1) break;
        if (n == des_pool[j].id) {
          dup = 1;
          break;
        }
        temp_pool.push_back(des_pool[j]);
      }
    }
    if (dup) continue;

    temp_pool.push_back(sn);
    if (temp_pool.size() > range) {
      std::vector<SimpleNeighbor> result;
      unsigned start = 0;
      std::sort(temp_pool.begin(), temp_pool.end());
      result.push_back(temp_pool[start]);
      while (result.size() < range && (++start) < temp_pool.size()) {
        auto &p = temp_pool[start];
        bool occlude = false;
        for (unsigned t = 0; t < result.size(); t++) {
          if (p.id == result[t].id) {
            occlude = true;
            break;
          }
          float djk = distance_->compare(
              data_ + dimension_ * (size_t)result[t].id,
              data_ + dimension_ * (size_t)p.id, (unsigned)dimension_);
          float cos_ij = (p.distance + result[t].distance - djk) / 2 /
                         sqrt(p.distance * result[t].distance);
          if (cos_ij > threshold) {
            occlude = true;
            break;
          }
        }
        if (!occlude) result.push_back(p);
      }
      {
        LockGuard guard(locks[des]);
        for (unsigned t = 0; t < result.size(); t++) {
          des_pool[t] = result[t];
        }
        if (result.size() < range) {
          des_pool[result.size()].distance = -1;
        }
      }
    } else {
      LockGuard guard(locks[des]);
      for (unsigned t = 0; t < range; t++) {
        if (des_pool[t].distance == -1) {
          des_pool[t] = sn;
          if (t + 1 < range) des_pool[t + 1].distance = -1;
          break;
        }
      }
    }
  }
}

void IndexSSG::Link(const Parameters &parameters, SimpleNeighbor *cut_graph_) {
  unsigned range = parameters.Get<unsigned>("R");
  std::vector<std::mutex> locks(nd_);

  float angle = parameters.Get<float>("A");
  float threshold = std::cos(angle / 180 * kPi);

#pragma omp parallel
  {
    std::vector<Neighbor> pool, tmp;
#pragma omp for schedule(dynamic, 100)
    for (unsigned n = 0; n < nd_; ++n) {
      pool.clear();
      tmp.clear();
      get_neighbors(n, parameters, pool);
      sync_prune(n, pool, parameters, threshold, cut_graph_);
    }

#pragma omp for schedule(dynamic, 100)
    for (unsigned n = 0; n < nd_; ++n) {
      InterInsert(n, range, threshold, locks, cut_graph_);
    }
  }
}

void kmeans_(
    float** train,
    float** result,
    int n,
    int d
){
        unsigned seed;
	float dist, min_dist;
	int min_id;
	int index;
	int round= 5;  //10
	float** temp_quan = new float*[LL];  //temp array for 
	int* tol_quan = new int[LL];  //the number of objects on each center 
	for(int i = 0; i < LL; i++)
		temp_quan[i] = new float[d];
	
	bool* flag= new bool[n];  // whether to choose it as a center
    for(int i = 0; i < n; i++)
		flag[i] = false;

    double rand_;
	for(int i = 0; i < LL; i++){  //generate L intial centers randomly
		 rand_ = double(i) / LL;
		 index = int( (n-1) * rand_);
		if(index < 0 || index >= n){
			printf("random_generator error\n");
			exit(0);
		}
				
		if(flag[index] == false){
			for(int j = 0; j < d; j++)
			    result[i][j] = train[index][j];
			flag[index] = true;
		}
		else{
            i--;           //re-generate center
	    }	
	}
	
	return;
}

int QsortComp2(				// compare function for qsort
	const void* e1,						// 1st element
	const void* e2)						// 2nd element
{
	int ret = 0;
	k_elem* value1 = (k_elem *) e1;
	k_elem* value2 = (k_elem *) e2;
	if (value1->dist < value2->dist) {
		ret = -1;
	} else if (value1->dist > value2->dist) {
		ret = 1;
	} else {
		if (value1->id < value2->id) ret = -1;
		else if (value1->id > value2->id) ret = 1;
	}
	return ret;
}

void IndexSSG::rotation_(int vecsize, int dim_, const float* data, float* data2, float* R){  //not use
	 DistanceInnerProduct *dist_fast = (DistanceInnerProduct *)distance_;		
    #pragma omp parallel for		
	for(size_t i = 0; i < vecsize; i++){
        float* data3 = new float[dim_]; 
		for(int j = 0; j < dim_; j++){
			data3[j] = 0;
              data3[j] = compare00( R + j * dim_, data + i * dim_, (unsigned) dim_);		 
		}		
	    for(int l = 0; l < dim_; l++){
	        data2[i * dim_ + l] = data3[l];
	    }
	    delete[] data3;
	}			
}

void IndexSSG::Build(size_t n, const float *data,
                     const Parameters &parameters) {

  StopW stopw = StopW();	
  data_ = data;
  int vecdim_ = dimension_;
  std::string nn_graph_path = parameters.Get<std::string>("nn_graph_path");
  unsigned range = parameters.Get<unsigned>("R");
  Load_nn_graph(nn_graph_path.c_str());
  init_graph(parameters);
  SimpleNeighbor *cut_graph_ = new SimpleNeighbor[nd_ * (size_t)range];
  Link(parameters, cut_graph_);
  final_graph_.resize(nd_);

  for (size_t i = 0; i < nd_; i++) {
    SimpleNeighbor *pool = cut_graph_ + i * (size_t)range;
    unsigned pool_size = 0;
    for (unsigned j = 0; j < range; j++) {
      if (pool[j].distance == -1) {
        break;
      }
      pool_size = j;
    }
    ++pool_size;
    final_graph_[i].resize(pool_size);
    for (unsigned j = 0; j < pool_size; j++) {
      final_graph_[i][j] = pool[j].id;
    }
  }

  DFS_expand(parameters);
  
  unsigned max, min, avg;
  max = 0;
  min = nd_;
  avg = 0;
  for (size_t i = 0; i < nd_; i++) {
    auto size = final_graph_[i].size();

    max = max < size ? size : max;
    min = min > size ? size : min;
    avg += size;
  }
  avg /= 1.0 * nd_;
  printf("Degree Statistics: Max = %d, Min = %d, Avg = %d\n",
         max, min, avg);
  std::cout << "\t" << stopw.getElapsedTimeMicro() / 1000000 << " ms\n"; 

    int size_n = 10000;
	int min_dim = vecdim_ / max_book;
	int vecsize = nd_;
 
	float** train_org = new float* [size_n];
    for(int i = 0; i < size_n; i++)
        train_org[i] = new float[vecdim_];	
	
	float*** train = new float** [max_book];
	for(int i = 0; i < max_book; i++)
		train[i] = new float* [size_n];
	for(int i = 0; i < max_book; i++)
		for(int j = 0; j < size_n; j++)
			train[i][j] = new float[min_dim];	
	
	int count = 0;
	int interval = vecsize / size_n;
    int ind = 0;
    if(interval < 1) {interval = 1;}
	
	float min_real = 0.000001;
	while(true){
		int MaxM = final_graph_[ind].size();
	    for(int i = 0; i < MaxM; i++){
		    int obj_id = final_graph_[ind][i];
		    float sum = 0;
		    for(int j = 0; j < vecdim_; j++){
			    train_org[count][j] = data_[(size_t)obj_id * vecdim_ + j] - data_[(size_t)ind * vecdim_ + j];
                sum += train_org[count][j] * train_org[count][j];					
		    }
				
		    if (sum < min_real) continue; 
				
		    for(int j = 0; j < vecdim_; j++){
			    train_org[count][j] = train_org[count][j] / sqrt(sum);				
		    }				
				
		    count++;
		    if( count >= size_n ) break;
	    }
		 if( count >= size_n ) break;
		ind += interval;
	}

	int dim_ = vecdim_;
	CvMat* M_X = cvCreateMat(dim_, size_n, CV_32FC1);
	CvMat* M_XT = cvCreateMat(size_n, dim_, CV_32FC1);
	CvMat* M_X2 = cvCreateMat(dim_, size_n, CV_32FC1);
	
	CvMat* M_Y = cvCreateMat(dim_, size_n, CV_32FC1);
	CvMat* M_YT = cvCreateMat(size_n, dim_, CV_32FC1);
	CvMat* M_R = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* M_RC = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* M_RX = cvCreateMat(dim_, size_n, CV_32FC1);
	CvMat* M_RT = cvCreateMat(dim_, dim_, CV_32FC1);
	
	CvMat* ABt   = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* ABt_D = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* ABt_U = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* ABt_VT = cvCreateMat(dim_, dim_, CV_32FC1);
	
	for (int i = 0; i < M_XT->rows; i++) {
        for (int j = 0; j < M_XT->cols; j++) {
            cvmSet (M_XT, i, j, train_org[i][j]);
        }
    }
	
	
	StopW stopw_train0 = StopW();
	
	CvMat* pMean = cvCreateMat(1, dim_, CV_32FC1);
	CvMat* pEigVals = cvCreateMat(1, dim_, CV_32FC1);
	CvMat* pEigVecs = cvCreateMat(dim_, dim_, CV_32FC1);
	cvCalcPCA(M_XT, pMean, pEigVals, pEigVecs, CV_PCA_DATA_AS_ROW);
	CvMat* PCA_R = cvCreateMat(dim_, dim_, CV_32FC1);

	for (int i = 0; i < M_XT->rows; i++) {
        for (int j = 0; j < M_XT->cols; j++) {
            cvmSet (M_XT, i, j, train_org[i][j]);
        }
    }	
	
	float ssum;
	float* pca_arr = new float[dim_];
	
	int* ord = new int[max_book];
	int* ord2 = new int[dim_];
	k_elem* prod = new k_elem[max_book];
	
	//float ssum;

	for(int i = 0; i < dim_; i++){
		if(i < max_book){
			prod[i].dist = cvmGet (pEigVals, 0, i);
			prod[i].id = i;
			ord[i] = 1;
			ord2[i] = i * min_dim; 
		}
		
		if(i >= max_book){
			
			ssum = cvmGet (pEigVals, 0, i);
			qsort(prod, max_book,sizeof(k_elem), QsortComp2);
					
			for(int j = 0; j < max_book; j++){
				if( ord[ prod[j].id ]  < min_dim){
					ord2[i] = prod[j].id * min_dim +  ord[ prod[j].id ];
                    ord[ prod[j].id ]++;
                    prod[j].dist *= ssum;
                    break;					
				}
			}
		}	
	}
		
	for(int i = 0; i < dim_; i++){
	    for(int j = 0; j < dim_; j++){
	      pca_arr[j] = cvmGet(pEigVecs, i, j);
		}
		ssum = 0;
		for(int j = 0; j < dim_; j++){
			ssum += pca_arr[j] * pca_arr[j];
		}
		for(int j = 0; j < dim_; j++){
		    cvmSet(PCA_R, ord2[i], j, pca_arr[j]/sqrt(ssum));
		}
	}	
		
	cvTranspose( M_XT, M_X );
	cvMatMul( PCA_R, M_X, M_X2 );
    for(int i = 0; i < size_n; i++){
		for(int j = 0; j < dim_; j++){
			train_org[i][j] = cvmGet (M_X2, j, i);
		}
	}

	for(int i = 0; i < size_n; i++){
		for(int ii = 0; ii < max_book; ii++){ 
			for(int jj = 0; jj < min_dim; jj++){
				train[ii][i][jj] = train_org[i][ii * min_dim +jj];
			}
		}
	}	
	
	float*** vec = new float** [max_book];
	for(int i = 0; i < max_book; i++){
		vec[i] = new float* [LL];
	}
  
    for(int i = 0; i < max_book; i++){
		for(int l = 0; l < LL; l++){ 
	        vec[i][l] = new float[min_dim];     
		}
	}
	
	for(int i = 0; i < max_book; i++){ 
		kmeans_(train[i], vec[i], size_n, min_dim);
	}
	
	for(int i = 0; i < max_book; i++){
		
		double min_real = 0.00000001;
		double max_real = 100000000;
		
		for(int j = 0; j < LL; j++){
			float sum = 0;
            for(int l = 0; l < min_dim; l++)			
	            sum += vec[i][j][l] * vec[i][j][l]; 

	        if(sum > max_real || sum < min_real) {printf("error\n"); exit(0);}			
            for(int l = 0; l < min_dim; l++)
                vec[i][j][l] = vec[i][j][l]/ sqrt(max_book * sum);            		
		}
	}	
    
	int* pvec = new int[size_n];
	int ROUND1 = 5;
	int ROUND2 = 10;
	int min_vec;
	float temp, min_temp;
	int* tol_count = new int[LL];
	
	float* test_arr = new float[10];
	for(int i = 0; i < 10; i++){
		test_arr[i] = 0;
	}
	
	for(int k1 = 0; k1 < ROUND1; k1++){
		for(int i = 0; i < size_n; i++){	
            for(int j = 0; j < max_book; j++){
                float test0 = 0;				
		        for(int x = 0; x < min_dim; x++)
                    test0 += train_org[i][j* min_dim +x] * train_org[i][j* min_dim +x];

                for(int x = 0; x < min_dim; x++)
                    train_org[i][j* min_dim +x]	= train_org[i][j* min_dim +x] / sqrt(test0);				
			}
	    }			
	
		float err_ = 0;
	    for(int i = 0; i < 10; i++){
		    test_arr[i] = 0;
	    }		
		
	    for(int i = 0; i < max_book; i++){
		    for(int k2 = 0; k2 < ROUND2; k2++){ 
		        for(int j = 0; j < size_n; j++){  //assignment of train vectors			
			        for(int l = 0; l < LL; l++){
				        temp = 0;
                        for(int x = 0; x < min_dim; x++){
							temp += train_org[j][i* min_dim +x] * vec[i][l][x];
                        }
						
						if( l == 0) {min_temp = temp; min_vec = l;}
                        else if(temp > min_temp) {min_temp = temp; min_vec = l;}				
		            }
                     pvec[j] = min_vec;			
		        }
		
		        for(int j = 0; j < size_n; j++){
			        for(int x = 0; x < min_dim; x++){
			            vec[i][ pvec[j] ][x] = 0; 
			        }	
		        }
				                     
			    for(int j = 0; j < LL; j++) tol_count[j] = 0;
                for(int j = 0; j < size_n; j++){  // compute new vectors
			        for(int x = 0; x < min_dim; x++){
			            vec[i][ pvec[j] ][x] += train_org[j][i * min_dim + x];	
			        }	
				    tol_count[ pvec[j] ]++;
		        }
			    
                for(int j = 0; j < LL; j++){
					if(tol_count[j] == 0) continue; 
				    for(int l = 0; l < min_dim; l++){
					    vec[i][j][l] /= tol_count[j];
				    }
					float g = 0;					
					for(int l = 0; l < min_dim; l++){
					    g += vec[i][j][l] * vec[i][j][l];
					}
					for(int l = 0; l < min_dim; l++){
					    vec[i][j][l] = vec[i][j][l] / sqrt(g * max_book);
					}					
			    }
		    }
		
		    for(int j = 0; j < size_n; j++){
                for(int x = 0; x < min_dim; x++){
				    cvmSet (M_Y, i* min_dim + x, j, vec[i][pvec[j]][x]);
			    }
		    }	
	    }
	
        if(k1 == ROUND1 - 1) break;
	
        cvTranspose(M_Y, M_YT); // transpose

        if(k1 == 0)
        cvMatMul(M_X2, M_YT, ABt);
        else{ cvMatMul(M_RX, M_YT, ABt);}

	    cvSVD(ABt, ABt_D, ABt_U, ABt_VT, CV_SVD_V_T); //SVD
	    cvMatMul( ABt_U, ABt_VT, M_R );
	    cvTranspose(M_R, M_RT);
    	
	    if(k1 == 0){			
		    for (int i = 0; i < M_RC->rows; i++) {
                for (int j = 0; j < M_RC->cols; j++) {
				    if(i == j)
                        cvmSet (M_RC, i, j, 1);
			        else{
				        cvmSet (M_RC, i, j, 0);	
				    }
                }
            }
		    cvMatMul( PCA_R, M_RC, M_RC );	
	    }
      
        cvMatMul( M_RT, M_RC, M_RC );

	    cvMatMul( M_RC, M_X, M_RX );
           
        for(int i = 0; i < size_n; i++){
		    for(int j = 0; j < dim_; j++){
			    train_org[i][j] = cvmGet (M_RX, j, i);
		    }
	    }
	
	}	
	
	float* R = new float [dim_ * dim_];
	
	for(int i = 0; i < dim_; i++){
		for(int j = 0; j < dim_; j++){ 
            R[i * dim_ + j] = cvmGet (M_RC, i, j);
		}
	}
	
	float* data2 = new float[(size_t)vecsize * vecdim_]; 
    rotation_(vecsize, vecdim_, data, data2, R);
	
	float** norm_vec = new float* [vecsize];
	unsigned char** sub_norm_arr = new unsigned char* [vecsize];
			
	for(int i = 0; i < vecsize; i++) {
		norm_vec[i] = new float[max];	
		for(int j = 0; j < max; j++) norm_vec[i][j] = 0;
		
		sub_norm_arr[i] = new unsigned char[max];
        for(int j = 0; j < max; j++) sub_norm_arr[i][j] = 0;				
	}	
	
	size_t size_data_per_element_ = sizeof(float) + sub_dim * sizeof(float) + sub_dim * max_book * sizeof(unsigned char) + 
	max * sizeof(unsigned char) * ( 1 + sub_dim / len_proj);
	
	int ttest1 = size_data_per_element_;

	char* data_memory_ = (char *)malloc(size_data_per_element_ * vecsize);
	if(data_memory_ == NULL) printf("allocation error\n");
	
	int report_every = vecsize / 10;
	int j1 = 0;
#pragma omp parallel for	
	for(size_t cur_id = 0; cur_id < vecsize; cur_id++){
		
	#pragma omp critical
        {
            j1++;
			if(j1 % report_every == 0)
		        printf("GAQ construction...%.2f %% completed\n", (size_t) j1 * 100 / float(vecsize) );            
	    }	

		double PI = 3.14159265358979323;

		int sz_link_list_other = final_graph_[cur_id].size();
			
		int sub_dim0 = sub_dim;
		if(sz_link_list_other < sub_dim) {
			if(sz_link_list_other < 2) {
				char* loc0 = data_memory_ + size_data_per_element_ * cur_id;
			    memcpy(loc0, &sz_link_list_other, sizeof(int));   //write MaxM	
				
				continue;
			}
			else{
				if(sz_link_list_other % 2 == 0){
					sub_dim0 = sz_link_list_other;				    	
				}
				else{
					sub_dim0 = sz_link_list_other - 1;
				}
			}
	    }

		float** obj_vec = new float* [sz_link_list_other];
			
		for(int j = 0; j < sz_link_list_other; j++)
			obj_vec[j] = new float[vecdim_];
			
        for (size_t j = 0; j < sz_link_list_other; j++) { 			
            unsigned a= final_graph_[cur_id][j];
	
		    for (size_t l = 0; l < vecdim_; l++)
				obj_vec[j][l] = data2[(size_t)a * vecdim_ + l] - data2[(size_t) cur_id * vecdim_ + l];				
			}
			
			CvMat* M_X = cvCreateMat(sz_link_list_other, vecdim_, CV_32FC1);
			for (int l = 0; l < M_X->rows; l++) {
                for (int j = 0; j < M_X->cols; j++) {
                    cvmSet (M_X, l, j, obj_vec[l][j]);
                }
            }
						
	        CvMat* pMean = cvCreateMat(1, vecdim_, CV_32FC1);
	        CvMat* pEigVals = cvCreateMat(1, sz_link_list_other, CV_32FC1);
	        CvMat* pEigVecs = cvCreateMat(sz_link_list_other, vecdim_, CV_32FC1);
			
	        cvCalcPCA(M_X, pMean, pEigVals, pEigVecs, CV_PCA_DATA_AS_ROW);
			
	        CvMat* M_axe = cvCreateMat(sub_dim0, vecdim_, CV_32FC1);

	        float* pca_arr = new float[vecdim_];
	        float ssum = 0;
	        for(int i = 0; i < sub_dim0; i++){
	            for(int j = 0; j < vecdim_; j++){
	                pca_arr[j] = cvmGet(pEigVecs, i, j);
		        }
				
				for(int j = 0; j < vecdim_; j++){
		            cvmSet(M_axe, i, j, pca_arr[j]);
		        }
				
	        }
			delete[] pca_arr;  
            cvReleaseMat(&pMean);
            cvReleaseMat(&pEigVals);
            cvReleaseMat(&pEigVecs); 

	        unsigned char** proj_id = new unsigned char* [sub_dim0];
			for(int i = 0; i < sub_dim0; i++){
				proj_id[i] = new unsigned char[max_book];
			}
		    float* pca_arr2 = new float[sub_dim0];
	       
			for (int l = 0; l < M_X->rows; l++) {
                for (int j = 0; j < M_X->cols; j++) {
                    cvmSet (M_X, l, j, obj_vec[l][j]);
                }
            }
			
			for(int j = 0; j < sz_link_list_other; j++)
				delete[] obj_vec[j];
			
			delete[] obj_vec;

            int round = 3;
			float temp, max_temp;
			unsigned char min_vec = 0;
			unsigned char min_vec2 = 0;
			
			CvMat* M_Q = cvCreateMat(vecdim_, sub_dim0, CV_32FC1);
			CvMat* M_R = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
			CvMat* M_Y = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
			CvMat* M_YT = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
	
	        CvMat* ABt   = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
	        CvMat* ABt_D = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
	        CvMat* ABt_U = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
	        CvMat* ABt_VT = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);			
						
			float test_sum = 0;
            for(int k = 0; k < round; k++){
			    for(int i = 0; i < max_book; i++){
		            for(int j = 0; j < sub_dim0; j++){  //assignment of train vectors		
			            for(int l = 0; l < LL; l++){
				            temp = 0;
                            for(int x = 0; x < min_dim; x++){
			                    temp += (cvmGet(M_axe, j, i * min_dim + x) * vec[i][l][x]);
                            }
						
						    if( l == 0) {max_temp = temp; min_vec = l;}
                            else if(temp > max_temp) {max_temp = temp; min_vec = l;}				
		                }
						
				        if(k == round - 1)
						    proj_id[j][i] = min_vec;
				
                        for(int x = 0; x < min_dim; x++)
                            cvmSet(M_Q, i * min_dim + x, j, vec[i][min_vec][x]);				
		            }
			    }
					
			    if(k == round - 1){
					char* proj_vec = data_memory_ + cur_id * size_data_per_element_ + sizeof(float) + sub_dim * sizeof(float);
										
				    for(int i = 0; i < sub_dim0; i++){
				        memcpy(proj_vec, proj_id[i], max_book);
					    proj_vec += max_book;
				    }	 
				    break;
			    }
			
			    cvMatMul(M_axe, M_Q, M_Y);   
						
	            for(int i = 0; i < sub_dim0; i++){    
	                for(int j = 0; j < sub_dim0; j++){
	                    pca_arr2[j] = cvmGet(M_Y, j, i);
		            }
				
		            ssum = 0;
		            for(int j = 0; j < sub_dim0; j++){
			            ssum += pca_arr2[j] * pca_arr2[j];
		            }
				
		            for(int j = 0; j < sub_dim0; j++){
		                cvmSet(M_Y, j, i, pca_arr2[j]/sqrt(ssum));
		            }
	            }			
			
			    cvTranspose(M_Y, M_YT);
	            cvSVD(M_YT, ABt_D, ABt_U, ABt_VT, CV_SVD_V_T); //SVD
	            cvMatMul( ABt_U, ABt_VT, M_R );
				
				cvMatMul(M_R, M_axe, M_axe);
			}	

			for(int i = 0; i < sub_dim0; i++){
	            for(int j = 0; j < vecdim_; j++){
					cvmSet(M_axe, i, j, cvmGet(M_Q, j, i) );
				}
			}

			cvReleaseMat(&M_Q);	
			cvReleaseMat(&M_R);
			cvReleaseMat(&M_Y);
			cvReleaseMat(&M_YT);

			cvReleaseMat(&ABt);
			cvReleaseMat(&ABt_D);
			cvReleaseMat(&ABt_U);
			cvReleaseMat(& ABt_VT);			
			
			delete[] pca_arr2;
			for(int i = 0; i < sub_dim0; i++){
				delete[] proj_id[i];
			}
   			delete[] proj_id;
			
			CvMat* M_Z = cvCreateMat(sub_dim0, sz_link_list_other, CV_32FC1);
			CvMat* M_B = cvCreateMat(vecdim_, 1, CV_32FC1);
			CvMat* M_B0 = cvCreateMat(sub_dim0, 1, CV_32FC1);
			for(int i = 0; i < vecdim_; i++)
				cvmSet( M_B, i, 0, data2[cur_id * vecdim_ + i] );
		
		
			CvMat* M_XT = cvCreateMat(vecdim_, sz_link_list_other, CV_32FC1);
			cvTranspose(M_X, M_XT);
			
			cvMatMul(M_axe, M_XT, M_Z);
			
			cvMatMul(M_axe, M_B, M_B0);
			
		    cvReleaseMat(&M_axe);
			cvReleaseMat(&M_B);
			cvReleaseMat(&M_X);
			cvReleaseMat(&M_XT);	
			
			float* tmp_arr = new float[sub_dim0];
			for(int i = 0; i < sub_dim0; i++)
				tmp_arr[i] = cvmGet(M_B0, i, 0);  
										
			cvReleaseMat(&M_B0);
			
			char* loc = data_memory_ + size_data_per_element_ * cur_id;	
			int aaa = sz_link_list_other;
			memcpy(loc, &aaa, sizeof(int));   
			
			char* loc2 = data_memory_ + size_data_per_element_ * cur_id + sizeof(float);
			
			memcpy(loc2, (char *)tmp_arr, sub_dim0 * sizeof(float)); 
		    
			delete[] tmp_arr;

			char* proj_vec = data_memory_ + size_data_per_element_ * cur_id + sizeof(float) + sub_dim * sizeof(float) + sub_dim * max_book;
			unsigned char* proj_pos = new unsigned char[sub_dim0 / 2];
		
			for(int i = 0; i < sz_link_list_other; i++){
				
				norm_vec[cur_id][i] = 0;
				for(int j = 0; j < sub_dim0; j++)
				    norm_vec[cur_id][i] += cvmGet(M_Z, j, i) * cvmGet(M_Z, j, i);
				
				norm_vec[cur_id][i] = sqrt(norm_vec[cur_id][i]);

				for(int j = 0; j < sub_dim0; j++)
				    cvmSet(M_Z, j, i, cvmGet(M_Z, j, i) / norm_vec[cur_id][i]);
									
				proj_vec++;
				
				float test0 = 0;
		        for(int j = 0; j < sub_dim0 / 2; j++){
					float x_axis = cvmGet(M_Z, 2 * j, i);
			        float y_axis = cvmGet(M_Z, 2 * j + 1, i);

					ssum = sqrt( x_axis * x_axis + y_axis * y_axis);
					float inval_ = 1.0 / (sqrt_L + 1);
					
					for(int ii = 0; ii < sqrt_L; ii++){
						temp = fabs( (ii + 1) * inval_ - ssum );
						if(ii == 0) {min_vec = 0; max_temp = temp;}
						else{
							if(temp < max_temp){
								max_temp = temp;
								min_vec = ii;
							}
						}
					}
										
					float angle = 0;
					if( x_axis == 0 && y_axis > 0) {
						angle = PI / 2;
					}
					else if( x_axis == 0 && y_axis < 0 ){
						angle = 3 * PI / 2;
					}
					
					if(x_axis != 0){
					    angle = atan(y_axis / x_axis);
					    
						if(x_axis < 0) angle += PI; 
					    else if( x_axis > 0 && y_axis < 0 ) angle += 2 * PI;

					}
						
					inval_ = 360.0 / sqrt_L;
					ssum = 360.0 * angle / (2 * PI);
					for(int ii = 0; ii < sqrt_L; ii++){
						temp = fabs( ii * inval_ - ssum );
						if(ii == 0) {min_vec2 = 0; max_temp = temp;}
						else{
							if(temp < max_temp){
								max_temp = temp;
								min_vec2 = ii;
							}
						}
					}
                    proj_pos[j] = (unsigned char) ( min_vec * sqrt_L + min_vec2);					
     			}
							
				memcpy(proj_vec, proj_pos, sub_dim0 / 2);				
				proj_vec += sub_dim0 / 2;
			}
			delete[] proj_pos;
            cvReleaseMat(&M_Z);
	}
	 
	float cur_max = -1.0f;

	for(int i = 0; i < vecsize; i++){
		for(int j = 0; j < max; j++){
			if(norm_vec[i][j] > cur_max)
				cur_max = norm_vec[i][j];
		}
	}
	int ttt = size_data_per_element_;
	for(int i = 0; i < vecsize; i++){
		for(int j = 0; j < max; j++){
		    sub_norm_arr[i][j] = (unsigned char) (LL * norm_vec[i][j] / cur_max);
		}
	}		
	
	for(int i = 0; i < vecsize; i++){
				
		int kp = size_data_per_element_;
				
		unsigned* ll_other = (unsigned *)(data_memory_ + size_data_per_element_ * i);
	    unsigned sz_link_list_other0 = *ll_other;
								
		if(sz_link_list_other0 < 1 || sz_link_list_other0 > max){
			printf(" i = %d; error size = %d; graph = %d\n", i, sz_link_list_other0, final_graph_[i].size());
			exit(0);
		}

		int sub_dim0 = sub_dim;
		if(sz_link_list_other0 < sub_dim) {
		    if(sz_link_list_other0 % 2 == 0){
			    sub_dim0 = sz_link_list_other0;				    	
		    }
			
		    else{
			    sub_dim0 = sz_link_list_other0 - 1;
			}
		}				
					
		if(sz_link_list_other0 <= 1) continue;
		    unsigned char* proj_vec = (unsigned char*) (data_memory_ + size_data_per_element_ * 
		    i + sizeof(float) + sub_dim * sizeof(float) + sub_dim * max_book);
				
		    for(int j = 0; j < sz_link_list_other0; j++){
				memcpy(proj_vec, &(sub_norm_arr[i][j]), 1);				
				proj_vec += (1 + sub_dim0 / 2);
		    }	
	}
		
    std::ofstream outputQ2("searching.bin", std::ios::binary);	
    outputQ2.write((char *) R, 4 * dim_ * dim_);
	
	outputQ2.write((char *) &cur_max, sizeof(float));
	outputQ2.write((char *) &vecsize, sizeof(int));
	
	int aa = size_data_per_element_;
	outputQ2.write((char *) &aa, sizeof(int));
		
	for(int i = 0; i < max_book; i++){
		for(int j = 0; j < LL; j++){
			outputQ2.write((char*) vec[i][j], 4 * min_dim);			
		}
    }			 
	outputQ2.close(); 
	
    std::ofstream outputQ1("info.bin", std::ios::binary);
	
	outputQ1.write((char *) &aa, sizeof(int));
	outputQ1.write((char *) &vecsize, sizeof(int));
	outputQ1.write((char *) &vecdim_, sizeof(int));
	
	int xx = sizeof(int) + sub_dim * sizeof(float) + sub_dim * max_book * sizeof(unsigned char);
	int yy = sizeof(unsigned char) * ( 1 + sub_dim / len_proj);	

	outputQ1.write((char *) &xx, sizeof(int));
	outputQ1.write((char *) &yy, sizeof(int));

	for(size_t i = 0; i < nd_; i++){
		int maxM =  *( (int *) (data_memory_ + i * size_data_per_element_) );
		outputQ1.write((char *) data_memory_ + i * size_data_per_element_, xx);
		outputQ1.write((char *) data_memory_ + i * size_data_per_element_ + xx, maxM * yy);
	}	
			
  has_built = true;
}

void IndexSSG::Search(const float *query, const float *x, size_t K,
                      const Parameters &parameters, unsigned *indices) {
  const unsigned L = parameters.Get<unsigned>("L_search");
  data_ = x;
  std::vector<Neighbor> retset(L + 1);
  std::vector<unsigned> init_ids(L);
  boost::dynamic_bitset<> flags{nd_, 0};
  std::mt19937 rng(rand());
  GenRandom(rng, init_ids.data(), L, (unsigned)nd_);
  assert(eps_.size() < L);
  for(unsigned i=0; i<eps_.size(); i++){
    init_ids[i] = eps_[i];
  }

  for (unsigned i = 0; i < L; i++) {
    unsigned id = init_ids[i];
    float dist = distance_->compare(data_ + dimension_ * id, query,
                                    (unsigned)dimension_);
    retset[i] = Neighbor(id, dist, true);
    flags[id] = true;
  }

  std::sort(retset.begin(), retset.begin() + L);
  int k = 0;
  while (k < (int)L) {
    int nk = L;

    if (retset[k].flag) {
      retset[k].flag = false;
      unsigned n = retset[k].id;

      for (unsigned m = 0; m < final_graph_[n].size(); ++m) {
        unsigned id = final_graph_[n][m];
        if (flags[id]) continue;
        flags[id] = 1;
        float dist = distance_->compare(query, data_ + dimension_ * id,
                                        (unsigned)dimension_);
        if (dist >= retset[L - 1].distance) continue;
        Neighbor nn(id, dist, true);
        int r = InsertIntoPool(retset.data(), L, nn);

        if (r < nk) nk = r;
      }
    }
    if (nk <= k)
      k = nk;
    else
      ++k;
  }
  for (size_t i = 0; i < K; i++) {
    indices[i] = retset[i].id;
  }
}

float projdistfunc_(float* b, unsigned char* a, int X, float* book){	
	float result = 0;
	float diff0, diff1, diff2, diff3;
    const float* last = b + X;
    const float* unroll_group = last - 3;
    int c, d;

    while (b < unroll_group) {
	    c = a[0] + a[0];
		d = a[1] + a[1];
				
        diff0 = book[c] * b[0];
        diff1 = book[c + 1] * b[1];
        diff2 = book[d] * b[2];
        diff3 = book[d + 1] * b[3];
        result += diff0 + diff1 + diff2 + diff3;
        a += 2;
        b += 4;
    }
	
    return result;
}
		
float querydistfunc_(unsigned char* id, int num, float** book){
	float dist = 0;

	float diff0, diff1, diff2, diff3;
    const unsigned char* last = id + num;
    const unsigned char* unroll_group = last - 3;
    int x = 0;
    /* Process 4 items with each loop for efficiency. */
    while (id < unroll_group) {
				
        diff0 = book[x][id[0]];
        diff1 = book[x+1][id[1]];
        diff2 = book[x+2][id[2]];
        diff3 = book[x+3][id[3]];
        dist += diff0 + diff1 + diff2 + diff3;
        id += 4;
		x += 4;
    } 
    return dist;			
}

void IndexSSG::SearchWithOptGraph(const float *query, size_t K,
                                  const Parameters &parameters,
                                  unsigned *indices, float** book_, float* book2_, float* norm_book, size_t size_data_per_element, 
								  VisitedListPool *visited_list_pool_) {
									  									  
  unsigned L = parameters.Get<unsigned>("L_search");
  DistanceFastL2 *dist_fast = (DistanceFastL2 *)distance_;
  int Min_cand = 8;
   VisitedList *vl = visited_list_pool_->getFreeVisitedList();
   vl_type *visited_array = vl->mass;
   vl_type visited_array_tag = vl->curV;  
  
  std::vector<Neighbor> retset(L + 1);
  std::vector<Neighbor> retset0(width + 1);  //add
  
  std::vector<unsigned> init_ids(L);
  std::mt19937 rng(rand());
  GenRandom(rng, init_ids.data(), L, (unsigned)nd_);
  
  assert(eps_.size() < L);
  for(unsigned i=0; i<eps_.size(); i++){
    init_ids[i] = eps_[i];
  }

  for (unsigned i = 0; i < init_ids.size(); i++) {
    unsigned id = init_ids[i];
    if (id >= nd_) continue;
    _mm_prefetch(opt_graph_ + node_size * id, _MM_HINT_T0);
  }
  L = 0;
  for (unsigned i = 0; i < init_ids.size(); i++) {
    unsigned id = init_ids[i];
    if (id >= nd_) continue;
    float *x = (float *)(opt_graph_ + node_size * id);
    float norm_x = *x;
    x++;
    float dist = dist_fast->compare(x, query, norm_x, (unsigned)dimension_);
    retset[i] = Neighbor(id, dist, true);
    visited_array[id] = visited_array_tag;   		
    L++;
  }

  std::sort(retset.begin(), retset.begin() + L);
  int k = 0;
  
  float* query_proj = new float[sub_dim];
  int l_num = L;
  int sub_dim0;
  
  size_t vecpos = data_len + sizeof(float) + sub_dim * sizeof(float) + sub_dim * max_book;
  while (k < (int)L) {
    int nk = L;

    if (retset[k].flag) {
      retset[k].flag = false;
      unsigned n = retset[k].id;

      _mm_prefetch(opt_graph_ + node_size * n + data_len, _MM_HINT_T0);
      unsigned *neighbors = (unsigned *)(opt_graph_ + node_size * n + data_len);
      unsigned MaxM = *neighbors;
      neighbors++;

	  bool fflag = true;
	  int sub_dim0 = sub_dim;	  

      if(MaxM > 2){  
		  
		 if(MaxM < sub_dim){ 
		    if(MaxM % 2 == 0){sub_dim0 = MaxM;} 
		    else{sub_dim0 = MaxM - 1;}
		 }
	
         float* base_vec = (float* ) neighbors;      
         neighbors += sub_dim;
	  
	     unsigned char* neighbors5 = (unsigned char*) neighbors;
	  
	     unsigned char* neighbors2 = (unsigned char*) (opt_graph_ + node_size * n + vecpos);
	     for(int i = 0; i < sub_dim0; i++){ 
	  
	      unsigned char* tmp_point = neighbors5;
	      query_proj[i] = querydistfunc_(tmp_point, max_book, book_);   
	   	  query_proj[i] = query_proj[i] - base_vec[i];
        	  
	   	  neighbors5 += max_book;
	    }
      
	    int X2 = sub_dim0 / 2;       
        int cand_count = 0;

        unsigned* datal =  (unsigned*) (opt_graph_ + node_size * n + data_len + size_data_per_element + sizeof(float));

	    for(int i = 0; i < MaxM; i++){
          if(visited_array[datal[i]] == visited_array_tag){
			  neighbors2 += (X2+1);
			  continue;
		  }
	  
		  float norm = norm_book[*neighbors2];
		  neighbors2++;
		  
		  unsigned char* tmp_point = neighbors2;
		  float dist0 = projdistfunc_(query_proj, tmp_point, sub_dim0, book2_);
		  		  
		  neighbors2 += X2;
		  dist0 = norm * norm - 2 * norm * dist0;
		   	  
          			
		  if(cand_count == 0) 
		    retset0[0] = Neighbor(i, dist0, true);
		  else{
			Neighbor nn0(i, dist0, true);
		    int r = InsertIntoPool(retset0.data(), cand_count, nn0);
		  }
		  
		  cand_count++;
	  }
	    
	  neighbors = (unsigned *) neighbors2;
	  neighbors++; 
	   
	  if(Min_cand < cand_count)
		 MaxM = Min_cand; 
	  else
		 MaxM = cand_count;
	  }
      else{
		  fflag = false;
	  }	  
	  
	  neighbors = (unsigned*) (opt_graph_ + node_size * n + data_len + size_data_per_element + sizeof(float));
	  if(fflag == true){
          for (unsigned m = 0; m < MaxM; ++m)
	          _mm_prefetch(opt_graph_ + node_size * neighbors[ retset0[m].id ], _MM_HINT_T0);
	  } 
	   else{
	        for (unsigned m = 0; m < MaxM; ++m)
                _mm_prefetch(opt_graph_ + node_size * neighbors[m], _MM_HINT_T0);
	   }
	
	  bool tflag = false;
	  int opp = 0;
      for (unsigned m = 0; m < MaxM; ++m) {
        unsigned id = neighbors[m];
		
	  if(fflag == true){
		 id = neighbors[ retset0[m].id ];
		 visited_array[id] = visited_array_tag;  
	  }	
	  else{	
		if(visited_array[id] == visited_array_tag) continue;
            visited_array[id] = visited_array_tag;   			
	  }	
		
      float *data = (float *)(opt_graph_ + node_size * id);
      float norm = *data;
      data++;
      float dist =
           dist_fast->compare(query, data, norm, (unsigned)dimension_);

      int r;
      if(l_num == L){
		  if (dist >= retset[L - 1].distance) {
				 opp++;
				 if(opp >= 3) break;
				 else continue;  
			}
	      
			Neighbor nn2(id, dist, true);
            r = InsertIntoPool(retset.data(), L, nn2);
		}
		else{
            Neighbor nn(id, dist, true);
            int r = InsertIntoPool(retset.data(), l_num, nn);
			l_num++;
        }
        if (r < nk) nk = r;
      }
    }
    if (nk <= k)
      k = nk;
    else
      ++k;
  }
  for (size_t i = 0; i < K; i++) {
    indices[i] = retset[i].id;
  } 
   visited_list_pool_->releaseVisitedList(vl);
}

void IndexSSG::OptimizeGraph(const float *data) {  

    size_t size_data_per_element = 0;
	int a, vecdim;
	int vecsize;

  	std::ifstream inQ("info.bin", std::ios::binary);
	inQ.read((char *) &a, sizeof(int) );
	size_data_per_element = a;
	
    inQ.read((char *) &a, sizeof(int) );
	vecsize = a;

	inQ.read((char *) &a, sizeof(int) );
	vecdim = a;
	char* data_memory = (char*) malloc(size_data_per_element * vecsize);
	
	int xx, yy;
	inQ.read((char *) &xx, sizeof(int) );
	inQ.read((char *) &yy, sizeof(int) );
	
	for(size_t i = 0; i < nd_; i++){
		int maxM;
		inQ.read((char *) &maxM, sizeof(int) );
        memcpy(data_memory + i * size_data_per_element, &maxM, sizeof(int));
		
        inQ.read((char *) data_memory + i * size_data_per_element + sizeof(int), xx - sizeof(int) );
	
		inQ.read((char *) data_memory + i * size_data_per_element + xx, maxM * yy );;
	}	
		
    int tol_dim = vecdim;
    float* R = new float [tol_dim * tol_dim];

    std::ifstream inQ2("searching.bin", std::ios::binary); 
    inQ2.read((char *) R, 4 * tol_dim * tol_dim);

    inQ.close();
	inQ2.close();
	
    float* data2 = new float[(size_t)vecsize * vecdim]; 
    rotation_(vecsize, vecdim, data, data2, R);
    data_ = data2;

    data_len = (dimension_ + 1) * sizeof(float);
    neighbor_len = (width + 1) * sizeof(unsigned);
    node_size = data_len + neighbor_len + size_data_per_element;
    opt_graph_ = (char *)malloc(node_size * nd_);
    DistanceFastL2 *dist_fast = (DistanceFastL2 *)distance_;
  
  for (unsigned i = 0; i < nd_; i++) {
    char *cur_node_offset = opt_graph_ + i * node_size;
    float cur_norm = dist_fast->norm(data_ + i * dimension_, dimension_);
    std::memcpy(cur_node_offset, &cur_norm, sizeof(float));
    std::memcpy(cur_node_offset + sizeof(float), data_ + i * dimension_,
                data_len - sizeof(float));

    cur_node_offset += data_len;
    unsigned k = final_graph_[i].size();

	std::memcpy(cur_node_offset, data_memory + i * size_data_per_element, size_data_per_element);
	cur_node_offset += size_data_per_element;

    std::memcpy(cur_node_offset, &k, sizeof(unsigned));
    std::memcpy(cur_node_offset + sizeof(unsigned), final_graph_[i].data(),
                k * sizeof(unsigned));
    std::vector<unsigned>().swap(final_graph_[i]);
  }
  CompactGraph().swap(final_graph_);
}

void IndexSSG::DFS(boost::dynamic_bitset<> &flag,
                   std::vector<std::pair<unsigned, unsigned>> &edges,
                   unsigned root, unsigned &cnt) {
  unsigned tmp = root;
  std::stack<unsigned> s;
  s.push(root);
  if (!flag[root]) cnt++;
  flag[root] = true;
  while (!s.empty()) {
    unsigned next = nd_ + 1;
    for (unsigned i = 0; i < final_graph_[tmp].size(); i++) {
      if (flag[final_graph_[tmp][i]] == false) {
        next = final_graph_[tmp][i];
        break;
      }
    }
    // std::cout << next <<":"<<cnt <<":"<<tmp <<":"<<s.size()<< '\n';
    if (next == (nd_ + 1)) {
      unsigned head = s.top();
      s.pop();
      if (s.empty()) break;
      tmp = s.top();
      unsigned tail = tmp;
      if (check_edge(head, tail)) {
        edges.push_back(std::make_pair(head, tail));
      }
      continue;
    }
    tmp = next;
    flag[tmp] = true;
    s.push(tmp);
    cnt++;
  }
}

void IndexSSG::findroot(boost::dynamic_bitset<> &flag, unsigned &root,
                        const Parameters &parameter) {
  unsigned id = nd_;
  for (unsigned i = 0; i < nd_; i++) {
    if (flag[i] == false) {
      id = i;
      break;
    }
  }

  if (id == nd_) return;  // No Unlinked Node

  std::vector<Neighbor> tmp, pool;
  get_neighbors(data_ + dimension_ * id, parameter, tmp, pool);
  std::sort(pool.begin(), pool.end());

  bool found = false;
  for (unsigned i = 0; i < pool.size(); i++) {
    if (flag[pool[i].id]) {
      // std::cout << pool[i].id << '\n';
      root = pool[i].id;
      found = true;
      break;
    }
  }
  if (!found) {
    for (int retry = 0; retry < 1000; ++retry) {
      unsigned rid = rand() % nd_;
      if (flag[rid]) {
        root = rid;
        break;
      }
    }
  }
  final_graph_[root].push_back(id);
}

bool IndexSSG::check_edge(unsigned h, unsigned t) {
  bool flag = true;
  for (unsigned i = 0; i < final_graph_[h].size(); i++) {
    if (t == final_graph_[h][i]) flag = false;
  }
  return flag;
}

void IndexSSG::strong_connect(const Parameters &parameter) {
  unsigned n_try = parameter.Get<unsigned>("n_try");
  std::vector<std::pair<unsigned, unsigned>> edges_all;
  std::mutex edge_lock;

#pragma omp parallel for
  for (unsigned nt = 0; nt < n_try; nt++) {
    unsigned root = rand() % nd_;
    boost::dynamic_bitset<> flags{nd_, 0};
    unsigned unlinked_cnt = 0;
    std::vector<std::pair<unsigned, unsigned>> edges;

    while (unlinked_cnt < nd_) {
      DFS(flags, edges, root, unlinked_cnt);
      // std::cout << unlinked_cnt << '\n';
      if (unlinked_cnt >= nd_) break;
      findroot(flags, root, parameter);
      // std::cout << "new root"<<":"<<root << '\n';
    }

    LockGuard guard(edge_lock);

    for (unsigned i = 0; i < edges.size(); i++) {
      edges_all.push_back(edges[i]);
    }
  }
  unsigned ecnt = 0;
  for (unsigned e = 0; e < edges_all.size(); e++) {
    unsigned start = edges_all[e].first;
    unsigned end = edges_all[e].second;
    unsigned flag = 1;
    for (unsigned j = 0; j < final_graph_[start].size(); j++) {
      if (end == final_graph_[start][j]) {
        flag = 0;
      }
    }
    if (flag) {
      final_graph_[start].push_back(end);
      ecnt++;
    }
  }
  for (size_t i = 0; i < nd_; ++i) {
    if (final_graph_[i].size() > width) {
      width = final_graph_[i].size();
    }
  }
}

void IndexSSG::DFS_expand(const Parameters &parameter) {
  unsigned n_try = parameter.Get<unsigned>("n_try");
  unsigned range = parameter.Get<unsigned>("R");

  std::vector<unsigned> ids(nd_);
  for(unsigned i=0; i<nd_; i++){
    ids[i]=i;
  }
  std::random_shuffle(ids.begin(), ids.end());
  for(unsigned i=0; i<n_try; i++){
    eps_.push_back(ids[i]);
    //std::cout << eps_[i] << '\n';
  }
#pragma omp parallel for
  for(unsigned i=0; i<n_try; i++){
    unsigned rootid = eps_[i];
    boost::dynamic_bitset<> flags{nd_, 0};
    std::queue<unsigned> myqueue;
    myqueue.push(rootid);
    flags[rootid]=true;

    std::vector<unsigned> uncheck_set(1);

    while(uncheck_set.size() >0){
      while(!myqueue.empty()){
        unsigned q_front=myqueue.front();
        myqueue.pop();

        for(unsigned j=0; j<final_graph_[q_front].size(); j++){
          unsigned child = final_graph_[q_front][j];
          if(flags[child])continue;
          flags[child] = true;
          myqueue.push(child);
        }
      }

      uncheck_set.clear();
      for(unsigned j=0; j<nd_; j++){
        if(flags[j])continue;
        uncheck_set.push_back(j);
      }
      //std::cout <<i<<":"<< uncheck_set.size() << '\n';
      if(uncheck_set.size()>0){
        for(unsigned j=0; j<nd_; j++){
          if(flags[j] && final_graph_[j].size()<range){
            final_graph_[j].push_back(uncheck_set[0]);
            break;
          }
        }
        myqueue.push(uncheck_set[0]);
        flags[uncheck_set[0]]=true;
      }
    }
  }
}

float compare_(float* a, float* b, unsigned size){ // !unchecked
	float result = 0;
	float diff0, diff1, diff2, diff3;
    const float* last = a + size;
    const float* unroll_group = last - 3;

    /* Process 4 items with each loop for efficiency. */
     while (a < unroll_group) {
        diff0 = a[0] * b[0];
        diff1 = a[1] * b[1];
        diff2 = a[2] * b[2];
        diff3 = a[3] * b[3];
        result += diff0 + diff1 + diff2 + diff3;
        a += 4;
        b += 4;
    }
    /* Process last 0-3 pixels.  Not needed for standard vector lengths. */
     while (a < last) {
        diff0 = (*a++) * (*b++);
        result += diff0;
    }
    return result;
}
		

void IndexSSG::restore_index(float *query_data, float* array0, float* book, int sdim, int tol_dim){ //!unchecked
    float* temp_arr2 = new float[sdim];

    int base_dim = sdim;	
	float* ind2 = array0 ;
			
	for(int j = 0; j < base_dim; j++){	
		temp_arr2[j] = compare00(ind2, query_data, (unsigned)dimension_);
        ind2 += tol_dim;			
	}   
 
	for(int j = 0; j < LL; j++){
		_mm_prefetch(ind2, _MM_HINT_T0);
		book[j] = compare_(ind2, temp_arr2, base_dim);
	    ind2 += base_dim;		
	}     	
}	
 
 void IndexSSG::query_rot(int dim_, int qsize, float* massQ, float * R){
	float* data3 = new float[dim_];

    for(int i = 0; i < qsize; i++){	
	    for(int j = 0; j < dim_; j++){
		    data3[j] = compare00( (R + j * dim_), (massQ + i * dim_), (unsigned) dim_);				        
	    }
        memcpy(massQ + i * dim_, data3, sizeof(float) * dim_);		
    }
 }

}  // namespace efanna2e
