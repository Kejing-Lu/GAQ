//
// Created by 付聪 on 2017/6/21.
//

#include <chrono>

#include "index_random.h"
#include "index_ssg.h"
#include "util.h"


void save_result(char* filename, std::vector<std::vector<unsigned> >& results) {
  std::ofstream out(filename, std::ios::binary | std::ios::out);

  for (unsigned i = 0; i < results.size(); i++) {
    unsigned GK = (unsigned)results[i].size();
    out.write((char*)&GK, sizeof(unsigned));
    out.write((char*)results[i].data(), GK * sizeof(unsigned));
  }
  out.close();
}

int main(int argc, char** argv) {
  if (argc < 6) {
    std::cout << "./run data_file query_file ssg_path L K result_path [seed]"
              << std::endl;
    exit(-1);
  }

  if (argc == 8) {
    unsigned seed = (unsigned)atoi(argv[7]);
    srand(seed);
    std::cerr << "Using Seed " << seed << std::endl;
  }

  std::cerr << "Data Path: " << argv[1] << std::endl;

  unsigned points_num, dim;
  float* data_load = nullptr;
  data_load = efanna2e::load_data(argv[1], points_num, dim);
  data_load = efanna2e::data_align(data_load, points_num, dim);

  VisitedListPool *visited_list_pool_ = new VisitedListPool(1, points_num);

  std::cerr << "Query Path: " << argv[2] << std::endl;

  unsigned query_num, query_dim;
  float* query_load = nullptr;
  query_load = efanna2e::load_data(argv[2], query_num, query_dim);
  query_load = efanna2e::data_align(query_load, query_num, query_dim);

  assert(dim == query_dim);

  efanna2e::IndexRandom init_index(dim, points_num);
  efanna2e::IndexSSG index(dim, points_num, efanna2e::FAST_L2,
                           (efanna2e::Index*)(&init_index));

  std::cerr << "SSG Path: " << argv[3] << std::endl;

  index.Load(argv[3]);

  index.OptimizeGraph(data_load);
   
  unsigned L = (unsigned)atoi(argv[4]);
  unsigned K = (unsigned)atoi(argv[5]);

  std::cerr << "L = " << L << ", ";
  std::cerr << "K = " << K << std::endl;

  std::cout << "Loading GT:\n";
  std::ifstream inputGT("truth.gt", std::ios::binary);
  int maxk = 100;
  unsigned int* massQA = new unsigned int[query_num * maxk]; 
  for (int i = 0; i < query_num; i++) {
      int t;
      inputGT.read((char *) &t, 4);
      inputGT.read((char *) (massQA + maxk * i), 4 * maxk);
  }
  inputGT.close();
 
    if (L < K) {
    std::cout << "search_L cannot be smaller than search_K!" << std::endl;
    exit(-1);
  }
  
  efanna2e::Parameters paras;
  paras.Set<unsigned>("L_search", L);

  std::vector<std::vector<unsigned> > res(query_num);
  for (unsigned i = 0; i < query_num; i++) res[i].resize(K);

  std::vector<unsigned int> efs; 
 
	int min_dim = dim / max_book;
    float*** vec = new float**[ max_book ];
    for(int i = 0; i < max_book; i++)
	    vec[i] = new float* [LL];
	
    for(int i = 0; i < max_book; i++){
	    for(int j = 0; j < LL; j++){
		    vec[i][j] = new float[ min_dim ];				
	    }
    }  
	
    int tol_dim = max_book * min_dim;
    float* R = new float [tol_dim * tol_dim];
 
  std::ifstream inQ2("searching.bin", std::ios::binary); 
  inQ2.read((char *) R, 4 * tol_dim * tol_dim);


   float cur_max;
   int vecsize;
   
    inQ2.read((char *) &cur_max, sizeof(float) );
	
	inQ2.read((char *) &vecsize, sizeof(int) );
	
	int a;
    inQ2.read((char *) &a, sizeof(int) );
	size_t size_data_per_elements = a;	
		
	float* norm_book = new float[LL];
	for(int i= 0; i < LL; i++) norm_book[i] =  1.0 * i / LL * cur_max;
	

  for(int i = 0; i < max_book; i++){
    for(int j = 0; j < LL; j++){
	  inQ2.read((char*) vec[i][j], 4 * min_dim);				
    }
  }	
   inQ2.close();  	
	
    int qsize = query_num;
    float*** book = new float** [qsize];
    for(int ii = 0; ii < qsize; ii++)
	    book[ii] = new float*[max_book];
		
    for(int ii = 0; ii < qsize; ii++)
	    for(int jj = 0; jj < max_book; jj++)
		    book[ii][jj] = new float [LL];
			
    for(int ii = 0; ii < qsize; ii++){
	    for(int l = 0; l < max_book; l++){
		    for(int ll = 0; ll < LL; ll++)
		        book[ii][l][ll] = 0;
	    } 
    }
  
  float* query_load2 = new float[qsize * tol_dim];
  float* tmp;
  float* tmp_query_load2;
  float* tmp_query_load;
  
  for(int i = 0; i < qsize; i++){
    	  tmp_query_load = query_load + i * dim;
     	  tmp_query_load2 = query_load2 + i * tol_dim;
      for(int j = 0; j < tol_dim; j++){
		  if(j < dim){
			  tmp_query_load2[j] = tmp_query_load[j];
		  }
		  else{
			  tmp_query_load2[j] = 0;
		  }
	  }
  }
  
  index.query_rot(dim, qsize, query_load, R);

float* array0 = new float[tol_dim * tol_dim + LL * tol_dim]; 
float* ind2; 

  for(int i = 0; i < max_book; i++){
	ind2 = array0 + i * (min_dim * tol_dim + LL * min_dim); 
	  
	for(int j = 0; j < min_dim * tol_dim; j++)
            ind2[j] = R[i * min_dim * tol_dim + j];

    ind2 += min_dim * tol_dim;		
	  
	for(int j = 0; j < LL; j++){ 
                ind2[j * min_dim ] = 0;
                for(int l = 0; l < min_dim; l++)
                    ind2[j * min_dim] += vec[i][j][l] * vec[i][j][l];

		for(int l = 0; l < min_dim; l++){
			    ind2[j * min_dim + l] = vec[i][j][l];
		}				
	}
  }	
  
 int const1 = min_dim * tol_dim + LL * min_dim;

#pragma omp parallel for  
  for (unsigned i = 0; i < qsize * max_book; i++) {
          int  j = i / max_book;
          int  l = i % max_book;
                     
          index.restore_index(query_load2 + j * tol_dim, array0 + l* const1, book[j][l], min_dim, tol_dim);

  } 
	
    double PI = 3.14159265358979323;
    float* book2 = new float[2 * LL];
	 
	for(int i = 0; i < sqrt_L; i++){
        for(int j = 0; j < sqrt_L; j++){
			book2[2 * (i * sqrt_L + j) ] = cos( j * 2.0 / sqrt_L * PI)  *  (i + 1) / (sqrt_L + 1);
		    book2[2 * (i * sqrt_L + j) + 1] = sin( j * 2.0 / sqrt_L * PI) * (i + 1) / (sqrt_L + 1);
		}
	}	
 
 /* 
     for (int i = K; i < 30; i++) {
        efs.push_back(i);
    } 
      for (int i = K; i < 100; i += 10) {
        efs.push_back(i);
    }
 */   
    for (int i = 100; i < 1000; i += 50) {
        efs.push_back(i);
    }
	
	    for (unsigned int ef : efs) {
    paras.Set<unsigned>("L_search", ef);
    paras.Set<unsigned>("P_search", ef);
  
   StopW stopw = StopW();
  for (unsigned i = 0; i < qsize; i++) {  //revise
    index.SearchWithOptGraph(query_load + i * dim, K, paras, res[i].data(), book[i], book2, norm_book, size_data_per_elements, visited_list_pool_);
  }
      float time_us_per_query = stopw.getElapsedTimeMicro() / query_num;
   std::cout << ef << "\t" << time_us_per_query << " us\n";
  
 	  unsigned int** answers = new unsigned int* [query_num];
  for(int i = 0; i < query_num; i++){
	  answers[i] = new unsigned int[K];
  }
  
  
  for (int i = 0; i < query_num; i++) {
      for (int j = 0; j < K; j++) {
          answers[i][j] = massQA[maxk * i + j];
      }
  }
  
  int correct = 0;
  int total = K* query_num;
   for (int i = 0; i < query_num; i++) {
        if(res[i].size() != K){
			printf("error\n");
			exit(0);	
		}
		for(int j = 0; j < K; j++){
			for(int l = 0; l < K; l++){
				if(answers[i][j] == res[i][l]){
					correct++;
					break;
				}
			}
			
		}	
		
    }		
	printf("recall = %.5f\n", 1.0f * correct / total); 
  
	}
  return 0;
}
