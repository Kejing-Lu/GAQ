# ------------------------------------------------------------------------------
#  Parameters
# ------------------------------------------------------------------------------
dname=gist
n=1000000
d=960
qn=1000

L=500
R=60 
C=60
T=100
K=100
dPath=./${dname}
qPath=./${dname}



./SSG-master/build/tests/test_ssg_index ${dPath}.ds data_graph.fvecs ${L} ${R} ${C} data_index.fvecs

./SSG-master/build/tests/test_ssg_optimized_search ${dPath}.ds ${qPath}.q data_index.fvecs ${T} ${K}

