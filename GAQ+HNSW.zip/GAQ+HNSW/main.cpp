#include <string.h>
#include <stdlib.h>

void sift_test1B(char*, char*, int, int, int, int, int);
int main(int argc, char **argv) {
	char  data_set[200];
	int vecsize_;
    int vecdim_;
    int level_;	
	float delta_;
	int qsize_;
	int efsearch_;
	
	//strncpy(data_set, argv[1], sizeof(data_set));
	vecsize_ = atoi(argv[3]);
	vecdim_ = atoi(argv[4]);
	qsize_ = atoi(argv[5]);
	delta_ = atoi(argv[6]);
	efsearch_ = atoi(argv[7]);
	
    sift_test1B(argv[1], argv[2], vecsize_, vecdim_,  qsize_, delta_, efsearch_);

    return 0;
};
