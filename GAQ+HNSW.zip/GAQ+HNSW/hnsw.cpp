#include <iostream>
#include <fstream>
#include <queue>
#include <chrono>
#include "hnswlib/hnswlib.h"
#include <ctime>
#include <cstdlib>

#include <unordered_set>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/imgproc/imgproc.hpp"


using namespace std;
using namespace hnswlib;
using namespace cv;

class StopW {
    std::chrono::steady_clock::time_point time_begin;
public:
    StopW() {
        time_begin = std::chrono::steady_clock::now();
    }

    float getElapsedTimeMicro() {
        std::chrono::steady_clock::time_point time_end = std::chrono::steady_clock::now();
        return (std::chrono::duration_cast<std::chrono::microseconds>(time_end - time_begin).count());
    }

    void reset() {
        time_begin = std::chrono::steady_clock::now();
    }

};


#if defined(_WIN32)
#include <windows.h>
#include <psapi.h>

#elif defined(__unix__) || defined(__unix) || defined(unix) || (defined(__APPLE__) && defined(__MACH__))

#include <unistd.h>
#include <sys/resource.h>

#if defined(__APPLE__) && defined(__MACH__)
#include <mach/mach.h>

#elif (defined(_AIX) || defined(__TOS__AIX__)) || (defined(__sun__) || defined(__sun) || defined(sun) && (defined(__SVR4) || defined(__svr4__)))
#include <fcntl.h>
#include <procfs.h>

#elif defined(__linux__) || defined(__linux) || defined(linux) || defined(__gnu_linux__)

#endif

#else
#error "Cannot define getPeakRSS( ) or getCurrentRSS( ) for an unknown OS."
#endif

/**
* Returns the peak (maximum so far) resident set size (physical
* memory use) measured in bytes, or zero if the value cannot be
* determined on this OS.
*/
static size_t getPeakRSS() {
#if defined(_WIN32)
    /* Windows -------------------------------------------------- */
    PROCESS_MEMORY_COUNTERS info;
    GetProcessMemoryInfo(GetCurrentProcess(), &info, sizeof(info));
    return (size_t)info.PeakWorkingSetSize;

#elif (defined(_AIX) || defined(__TOS__AIX__)) || (defined(__sun__) || defined(__sun) || defined(sun) && (defined(__SVR4) || defined(__svr4__)))
    /* AIX and Solaris ------------------------------------------ */
    struct psinfo psinfo;
    int fd = -1;
    if ((fd = open("/proc/self/psinfo", O_RDONLY)) == -1)
        return (size_t)0L;      /* Can't open? */
    if (read(fd, &psinfo, sizeof(psinfo)) != sizeof(psinfo))
    {
        close(fd);
        return (size_t)0L;      /* Can't read? */
    }
    close(fd);
    return (size_t)(psinfo.pr_rssize * 1024L);

#elif defined(__unix__) || defined(__unix) || defined(unix) || (defined(__APPLE__) && defined(__MACH__))
    /* BSD, Linux, and OSX -------------------------------------- */
    struct rusage rusage;
    getrusage(RUSAGE_SELF, &rusage);
#if defined(__APPLE__) && defined(__MACH__)
    return (size_t)rusage.ru_maxrss;
#else
    return (size_t) (rusage.ru_maxrss * 1024L);
#endif

#else
    /* Unknown OS ----------------------------------------------- */
    return (size_t)0L;          /* Unsupported. */
#endif
}


/**
* Returns the current resident set size (physical memory use) measured
* in bytes, or zero if the value cannot be determined on this OS.
*/
static size_t getCurrentRSS() {
#if defined(_WIN32)
    /* Windows -------------------------------------------------- */
    PROCESS_MEMORY_COUNTERS info;
    GetProcessMemoryInfo(GetCurrentProcess(), &info, sizeof(info));
    return (size_t)info.WorkingSetSize;

#elif defined(__APPLE__) && defined(__MACH__)
    /* OSX ------------------------------------------------------ */
    struct mach_task_basic_info info;
    mach_msg_type_number_t infoCount = MACH_TASK_BASIC_INFO_COUNT;
    if (task_info(mach_task_self(), MACH_TASK_BASIC_INFO,
        (task_info_t)&info, &infoCount) != KERN_SUCCESS)
        return (size_t)0L;      /* Can't access? */
    return (size_t)info.resident_size;

#elif defined(__linux__) || defined(__linux) || defined(linux) || defined(__gnu_linux__)
    /* Linux ---------------------------------------------------- */
    long rss = 0L;
    FILE *fp = NULL;
    if ((fp = fopen("/proc/self/statm", "r")) == NULL)
        return (size_t) 0L;      /* Can't open? */
    if (fscanf(fp, "%*s%ld", &rss) != 1) {
        fclose(fp);
        return (size_t) 0L;      /* Can't read? */
    }
    fclose(fp);
    return (size_t) rss * (size_t) sysconf(_SC_PAGESIZE);

#else
    /* AIX, BSD, Solaris, and Unknown OS ------------------------ */
    return (size_t)0L;          /* Unsupported. */
#endif
}

struct k_elem{
	int id;
	float dist;
};

int QsortComp(				// compare function for qsort
	const void* e1,						// 1st element
	const void* e2)						// 2nd element
{
	int ret = 0;
	k_elem* value1 = (k_elem *) e1;
	k_elem* value2 = (k_elem *) e2;
	if (value1->dist < value2->dist) {
		ret = -1;
	} else if (value1->dist > value2->dist) {
		ret = 1;
	} else {
		if (value1->id < value2->id) ret = -1;
		else if (value1->id > value2->id) ret = 1;
	}
	return ret;
}

static void
test_vs_recall(float *massQ, size_t vecsize, size_t qsize, HierarchicalNSW<float> &appr_alg, size_t vecdim,
               size_t k, int dim, int efsearch) {
    vector<size_t> efs;// = { 10,10,10,10,10 };

   //printf("topk = %d\n",k); 
   std::cout << "Loading GT:\n";
   std::ifstream inputGT("truth.gt", std::ios::binary);
   int maxk = 100;
   unsigned int* massQA = new unsigned int[qsize * maxk]; //alt
    for (int i = 0; i < qsize; i++) {
      int t;
      inputGT.read((char *) &t, 4);
      inputGT.read((char *) (massQA + 100 * i), 4 * maxk);
   }
   inputGT.close(); 
 
    int LL = L;
	int min_dim = dim / max_book;
    float*** vec = new float**[ max_book ];
    for(int i = 0; i < max_book; i++)
	    vec[i] = new float* [LL];
	
    for(int i = 0; i < max_book; i++){
	    for(int j = 0; j < LL; j++){
		    vec[i][j] = new float[ min_dim ];				
	    }
    }  
	
    int tol_dim = max_book * min_dim;
    float* R = new float [tol_dim * tol_dim];
  
  std::ifstream inQ2("searching.bin", std::ios::binary); 
  inQ2.read((char *) R, 4 * tol_dim * tol_dim);


   float cur_max;
    inQ2.read((char *) &cur_max, sizeof(float) );
	
	float* norm_book = new float[L];
	for(int i= 0; i < L; i++) norm_book[i] =  1.0 * i / L * cur_max;
	

  for(int i = 0; i < max_book; i++){
    for(int j = 0; j < LL; j++){
	  inQ2.read((char*) vec[i][j], 4 * min_dim);				
    }
  }	
   inQ2.close();  	
	
    float*** book = new float** [qsize];
    for(int ii = 0; ii < qsize; ii++)
	    book[ii] = new float*[max_book];
		
    for(int ii = 0; ii < qsize; ii++)
	    for(int jj = 0; jj < max_book; jj++)
		    book[ii][jj] = new float [LL];
			
    for(int ii = 0; ii < qsize; ii++){
	    for(int l = 0; l < max_book; l++){
		    for(int ll = 0; ll < LL; ll++)
		        book[ii][l][ll] = 0;
	    } 
    }
  
 std::vector<std::vector<unsigned> > res(qsize);
  for (unsigned i = 0; i < qsize; i++) res[i].resize(k);

  float* query_load2 = new float[qsize * tol_dim];
  float* tmp;
  float* tmp_query_load2;
  float* tmp_query_load;
  
  for(int i = 0; i < qsize; i++){
    	  tmp_query_load = massQ + i * vecdim;
     	  tmp_query_load2 = query_load2 + i * tol_dim;
      for(int j = 0; j < tol_dim; j++){
		  if(j < vecdim){
			  tmp_query_load2[j] = tmp_query_load[j];
		  }
		  else{
			  tmp_query_load2[j] = 0;
		  }
	  }
  }
  
  appr_alg.query_rot(dim, qsize, massQ, R);

float* array0 = new float[tol_dim * tol_dim + LL * tol_dim]; 
float* ind2; 

  for(int i = 0; i < max_book; i++){
	ind2 = array0 + i * (min_dim * tol_dim + LL * min_dim); 
	  
	for(int j = 0; j < min_dim * tol_dim; j++)
            ind2[j] = R[i * min_dim * tol_dim + j];

    ind2 += min_dim * tol_dim;		
	  
	for(int j = 0; j < LL; j++){ 
                ind2[j * min_dim ] = 0;
                for(int l = 0; l < min_dim; l++)
                    ind2[j * min_dim] += vec[i][j][l] * vec[i][j][l];

		for(int l = 0; l < min_dim; l++){
			    ind2[j * min_dim + l] = vec[i][j][l];
		}				
	}
  }	
  
  VisitedListPool *visited_list_pool_ = new VisitedListPool(1, vecsize);
 
 int const1 = min_dim * tol_dim + LL * min_dim;

#pragma omp parallel for  
  for (unsigned i = 0; i < qsize * max_book; i++) {
          int  j = i / max_book;
          int  l = i % max_book;
                     
          appr_alg.restore_index(query_load2 + j * tol_dim, array0 + l* const1, book[j][l], min_dim, tol_dim);

  } 

    double PI = 3.14159265358979323;
    float* book2 = new float[2 * LL];
	
	for(int i = 0; i < sqrt_L; i++){
        for(int j = 0; j < sqrt_L; j++){
			book2[2 * (i * sqrt_L + j) ] = cos( j * 2.0 / sqrt_L * PI)  *  (i + 1) / (sqrt_L + 1);
		    book2[2 * (i * sqrt_L + j) + 1] = sin( j * 2.0 / sqrt_L * PI) * (i + 1) / (sqrt_L + 1);
		}
	}	
	  	
    for (int i = efsearch; i < efsearch + 1; i += 1) {
       efs.push_back(i);
    }
    for (size_t ef : efs) {
        StopW stopw = StopW();

        for (unsigned ii = 0; ii < qsize; ii++) {
            appr_alg.SearchWithOptGraph(book[ii], book2, norm_book, massQ + ii * vecdim, k, ef, res[ii].data(), visited_list_pool_);
        }
		
       float time_us_per_query = stopw.getElapsedTimeMicro() / qsize;

        unsigned int** answers = new unsigned int* [qsize];
        for(int i = 0; i < qsize; i++){
	        answers[i] = new unsigned int[k];
        }
   
        for (int i = 0; i < qsize; i++) {
            for (int j = 0; j < k; j++) {
                answers[i][j] = massQA[maxk * i + j];
            }
        }
  
        int correct = 0;
        int total = k* qsize;
        for (int i = 0; i < qsize; i++) {
            if(res[i].size() != k){
			    printf("error\n");
			    exit(-1);	
		    }
		    for(int j = 0; j < k; j++){
			    for(int l = 0; l < k; l++){
				    if(answers[i][j] == res[i][l]){
					    correct++;
					    break;
				    }
			    }
		    }	
		
        }

       std::cout <<"efs="<< ef << "\t" << time_us_per_query << " us" << "\t" << "recall=" << 1.0f * correct / total <<endl;
    }
}

inline bool exists_test(const std::string &name) {
    ifstream f(name.c_str());
    return f.good();
}

struct elem_{
	unsigned char* index;
	int id;
	float dist;
};

void kmeans_(
    float** train,
    float** result,
    int n,
    int d
){
        unsigned seed;
	float dist, min_dist;
	int min_id;
	int index;
	int round= 5;  //10
	float** temp_quan = new float*[L];  //temp array for 
	int* tol_quan = new int[L];  //the number of objects on each center 
	for(int i = 0; i < L; i++)
		temp_quan[i] = new float[d];
	
	bool* flag= new bool[n];  // whether to choose it as a center
    for(int i = 0; i < n; i++)
		flag[i] = false;

    double rand_;
	for(int i = 0; i < L; i++){  //generate L intial centers randomly
		 rand_ = double(i) / L;
		 index = int( (n-1) * rand_);
		if(index < 0 || index >= n){
			printf("random_generator error\n");
			exit(0);
		}
				
		if(flag[index] == false){
			for(int j = 0; j < d; j++)
			    result[i][j] = train[index][j];
			flag[index] = true;
		}
		else{
            i--;           //re-generate center
	    }	
	}
	
	return;
    float temp_sum;
	
	for(int l = 0; l < round; l++){
	    temp_sum = 0;
		for(int i = 0; i < L; i++)
			for(int j = 0; j < d; j++)
		        temp_quan[i][j] = 0;
			
		for(int i = 0; i < L; i++)
            tol_quan[i] = 0;			
		
		for(int i = 0; i < n; i++){
			for(int ii = 0; ii < L; ii++){
			    dist = 0;
			    for(int j =0; j < d; j++)
				    dist += (train[i][j] - result[ii][j]) * (train[i][j] - result[ii][j]);
				
				if(ii == 0){
				    min_dist = dist;
				    min_id = 0;
                    continue;					
				}
				
			    if (dist < min_dist){
				    min_dist = dist;
				    min_id = ii;
			    }
		    }
			for(int j = 0; j < d; j++){
			    temp_quan[min_id][j] += train[i][j];
			}
			temp_sum += min_dist;
			tol_quan[min_id]++;
		}

		for(int i = 0; i < L; i++){
			if(tol_quan[i] == 0) continue;
			else{
				for(int j = 0; j < d; j++)
					result[i][j] = temp_quan[i][j] / tol_quan[i];
			}
		}
		
	}

}

int compare_int(const void * a, const void * b)
{
  return ( *(int*)a - *(int*)b );
}	

int compfloats(					
	float v1,							
	float v2)							
{
	const float FLOATZERO = 1e-6F;
	if (v1 - v2 < -FLOATZERO) return -1;  
	else if (v1 - v2 > FLOATZERO) return 1;
	else return 0;
}
		
void sift_test1B(
    char* path_data,
	char* path_q,
    int vecsize_,
	int vecdim_,
	int qsize,
	int topK,
	int efsearch) {

	int efConstruction = 2000;
	int M = 16;
    size_t vecsize = vecsize_;
    size_t vecdim = vecdim_;
	
	size_t dim_;		
	int remainder = vecdim % max_book;
	int ratio = vecdim / max_book;
	if(remainder == 0){dim_ = vecdim;}
    else{ dim_ = (ratio + 1)* max_book; }	
	int min_dim = dim_ / max_book;	
	
	int report_every = vecsize_ / 10;
	char path_index[1024];
    sprintf(path_index, "index.bin");
	
	vecdim = dim_;
	
    float *massb = new float[vecdim];
	float *mass = new float[vecdim];
	for(int i = 0; i < vecdim; i++){
		massb[i] = 0;
		mass[i] = 0;
	}
	
    ifstream input(path_data, ios::binary);
	
    int maxk = 100;
	const float MAXREAL   = 3.402823466e+38F;
	srand(time(NULL));
	
    int in = 0;
    L2Space l2space(vecdim, dim_);           
	
	HierarchicalNSW<float> *appr_alg;
	if(!exists_test(path_index))
    appr_alg = new HierarchicalNSW<float>(&l2space, vecsize, vecdim, M, efConstruction);
	
	if (exists_test(path_index)) {
		
	   cout << "Loading queries:\n";
           float *massQ = new float[qsize * vecdim];
		   
		   for(int i = 0; i < qsize * vecdim; i++)
		       massQ[i] = 0;
		   
          ifstream inputQ(path_q, ios::binary);
           for (int i = 0; i < qsize; i++) {
               int in = 0;
               inputQ.read((char *) &in, 4);
               inputQ.read((char *) massb, 4 * vecdim_);
               for (int j = 0; j < vecdim_; j++) {
                massQ[i * vecdim + j] = massb[j];
              }
           }
        inputQ.close();
        cout << "Loading index from " << path_index << ":\n";
        appr_alg = new HierarchicalNSW<float>(&l2space, path_index, false);

	    vector<std::priority_queue<std::pair<float, labeltype >>> answers;
        size_t k = topK;
        for (int i = 0; i < 1; i++)
            test_vs_recall(massQ, vecsize, qsize, *appr_alg, vecdim, k, dim_, efsearch);
		return;
    }    	        

	float*** train = new float** [max_book];
	for(int i = 0; i < max_book; i++)
		train[i] = new float* [size_n];
	for(int i = 0; i < max_book; i++)
		for(int j = 0; j < size_n; j++)
			train[i][j] = new float[min_dim];
		
	float** train_org = new float* [size_n]; 
    for(int i = 0; i < size_n; i++)
        train_org[i] = new float[dim_];	

	float** train_test = new float* [size_n]; 
    for(int i = 0; i < size_n; i++)
        train_test[i] = new float[dim_];	
	
    int interval = vecsize / size_n;
    int ind = -interval;
    if(interval < 1) {interval = 1;}
   
	input.seekg(0, std::ios::beg);	
	float** data = new float* [vecsize];   
	for(int i = 0; i < vecsize; i++)
		data[i] = new float[dim_];
	
	for(int i = 0; i < vecsize; i++){
		input.seekg(4, std::ios::cur);
		input.read((char*)(massb), vecdim_ * 4);
        for(int j= 0; j < dim_; j++){	
            if(j < vecdim_) {data[i][j] = massb[j];}
            else{data[i][j] = 0;}
		}    
	}

	StopW stopw_full = StopW();
	
	StopW stopw_base_layer = StopW();
	input.seekg(0, std::ios::beg);

    input.read((char *) &in, 4);
    input.read((char *) massb, 4 * vecdim_);

    for (int j = 0; j < vecdim; j++) {
        mass[j] = massb[j] * (1.0f);
    }
    
    appr_alg->addPoint((void *) (massb), (size_t) 0, true);
					      
    int j1 = 0;

#pragma omp parallel for	
    for (int i = 1; i < vecsize; i++) {
		int j2=0;
#pragma omp critical
        {
            input.read((char *) &in, 4);
            input.read((char *) massb, 4 * vecdim_);
            for (int j = 0; j < vecdim_; j++) {
                mass[j] = massb[j];
            }
            j1++;
            j2=j1;
			if(j1 % report_every == 0)
		        printf("build HNSW index...%.2f %% completed\n", (size_t) j1 * 100 / float(vecsize) );
            
	    }	
		appr_alg->addPoint((void *) (data[i]), (size_t) i, false);
    }
	
    cout << "Build HNSW time:" << 1e-6 * stopw_base_layer.getElapsedTimeMicro() << "  seconds\n";

	StopW stopw_train = StopW();
	
	ind = 0;
	int cur_num = 0;
	for(int i = 0; i < size_n; i++){
		appr_alg->find_neighbors(vecdim, train_org, ind, &cur_num, data);   
		if( cur_num >= size_n ) break;
		ind += interval;
	}

	CvMat* M_X = cvCreateMat(dim_, size_n, CV_32FC1);
	CvMat* M_XT = cvCreateMat(size_n, dim_, CV_32FC1);
	CvMat* M_X2 = cvCreateMat(dim_, size_n, CV_32FC1);
	
	CvMat* M_Y = cvCreateMat(dim_, size_n, CV_32FC1);
	CvMat* M_YT = cvCreateMat(size_n, dim_, CV_32FC1);
	CvMat* M_R = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* M_RC = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* M_RX = cvCreateMat(dim_, size_n, CV_32FC1);
	CvMat* M_RT = cvCreateMat(dim_, dim_, CV_32FC1);
	
	CvMat* ABt   = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* ABt_D = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* ABt_U = cvCreateMat(dim_, dim_, CV_32FC1);
	CvMat* ABt_VT = cvCreateMat(dim_, dim_, CV_32FC1);
	
	for (int i = 0; i < M_XT->rows; i++) {
        for (int j = 0; j < M_XT->cols; j++) {
            cvmSet (M_XT, i, j, train_org[i][j]);
        }
    }
	
	StopW stopw_train0 = StopW();

	CvMat* pMean = cvCreateMat(1, dim_, CV_32FC1);
	CvMat* pEigVals = cvCreateMat(1, dim_, CV_32FC1);
	CvMat* pEigVecs = cvCreateMat(dim_, dim_, CV_32FC1);
	cvCalcPCA(M_XT, pMean, pEigVals, pEigVecs, CV_PCA_DATA_AS_ROW);
	CvMat* PCA_R = cvCreateMat(dim_, dim_, CV_32FC1);

	for (int i = 0; i < M_XT->rows; i++) {
        for (int j = 0; j < M_XT->cols; j++) {
            cvmSet (M_XT, i, j, train_org[i][j]);
        }
    }	
	
	float ssum;
	float* pca_arr = new float[dim_];

	int* ord = new int[max_book];
	int* ord2 = new int[dim_];
	k_elem* prod = new k_elem[max_book];
	
	//float ssum;

	for(int i = 0; i < dim_; i++){
		if(i < max_book){
			prod[i].dist = cvmGet (pEigVals, 0, i);
			prod[i].id = i;
			ord[i] = 1;
			ord2[i] = i * min_dim; 
		}
		
		if(i >= max_book){
			
			ssum = cvmGet (pEigVals, 0, i);
			qsort(prod, max_book,sizeof(k_elem), QsortComp);
					
			for(int j = 0; j < max_book; j++){
				if( ord[ prod[j].id ]  < min_dim){
					ord2[i] = prod[j].id * min_dim +  ord[ prod[j].id ];
                    ord[ prod[j].id ]++;
                    prod[j].dist *= ssum;
                    break;					
				}
			}
		}	
	}
		
	for(int i = 0; i < dim_; i++){
	    for(int j = 0; j < dim_; j++){
	      pca_arr[j] = cvmGet(pEigVecs, i, j);
		}
		ssum = 0;
		for(int j = 0; j < dim_; j++){
			ssum += pca_arr[j] * pca_arr[j];
		}
		for(int j = 0; j < dim_; j++){
		    cvmSet(PCA_R, ord2[i], j, pca_arr[j]/sqrt(ssum));
		}
	}	
		
	cvTranspose( M_XT, M_X );
	cvMatMul( PCA_R, M_X, M_X2 );
    for(int i = 0; i < size_n; i++){
		for(int j = 0; j < dim_; j++){
			train_org[i][j] = cvmGet (M_X2, j, i);
			train_test[i][j] = cvmGet (M_X2, j, i);
		}
	}

	for(int i = 0; i < size_n; i++){
		for(int ii = 0; ii < max_book; ii++){ 
			for(int jj = 0; jj < min_dim; jj++){
				train[ii][i][jj] = train_org[i][ii * min_dim +jj];
			}
		}
	}	
	
	float*** vec = new float** [max_book];
	for(int i = 0; i < max_book; i++){
		vec[i] = new float* [L];
	}
  
    for(int i = 0; i < max_book; i++){
		for(int l = 0; l < L; l++){ 
	        vec[i][l] = new float[min_dim];     
		}
	}
	
	for(int i = 0; i < max_book; i++){ 
		kmeans_(train[i], vec[i], size_n, min_dim);
	}
	
	for(int i = 0; i < max_book; i++){
		
		double min_real = 0.00000001;
		double max_real = 100000000;
		
		for(int j = 0; j < L; j++){
			float sum = 0;
            for(int l = 0; l < min_dim; l++)			
	            sum += vec[i][j][l] * vec[i][j][l]; 

	        if(sum > max_real || sum < min_real) {printf("error\n"); exit(0);}			
            for(int l = 0; l < min_dim; l++)
                vec[i][j][l] = vec[i][j][l]/ sqrt(max_book * sum);            		
		}
	}	
    
	int* pvec = new int[size_n];
	int ROUND1 = 3;
	int ROUND2 = 10;
	int min_vec;
	float temp, min_temp;
	int* tol_count = new int[L];
	
	float* test_arr = new float[10];
	for(int i = 0; i < 10; i++){
		test_arr[i] = 0;
	}
	
	for(int k1 = 0; k1 < ROUND1; k1++){
		for(int i = 0; i < size_n; i++){	
            for(int j = 0; j < max_book; j++){
                float test0 = 0;				
		        for(int x = 0; x < min_dim; x++)
                    test0 += train_org[i][j* min_dim +x] * train_org[i][j* min_dim +x];

                for(int x = 0; x < min_dim; x++)
                    train_org[i][j* min_dim +x]	= train_org[i][j* min_dim +x] / sqrt(test0);				
			}
            float test1 = 0;				
		    for(int x = 0; x < dim_; x++)
                test1 += train_test[i][x] * train_test[i][x];
				
            for(int x = 0; x < dim_; x++)
                train_test[i][x] = train_test[i][x] / sqrt(test1);			
	    }			
	
		float err_ = 0;
	    for(int i = 0; i < 10; i++){
		    test_arr[i] = 0;
	    }		
		
	    for(int i = 0; i < max_book; i++){
		    for(int k2 = 0; k2 < ROUND2; k2++){  
		        for(int j = 0; j < size_n; j++){  		
			        for(int l = 0; l < L; l++){
				        temp = 0;
                        for(int x = 0; x < min_dim; x++){
							temp += train_org[j][i* min_dim +x] * vec[i][l][x];
                        }
						
						if( l == 0) {min_temp = temp; min_vec = l;}
                        else if(temp > min_temp) {min_temp = temp; min_vec = l;}				
		            }
                     pvec[j] = min_vec;		
		        }
		
		        for(int j = 0; j < size_n; j++){
			        for(int x = 0; x < min_dim; x++){
			            vec[i][ pvec[j] ][x] = 0; 
			        }	
		        }
				                     
			    for(int j = 0; j < L; j++) tol_count[j] = 0;
                for(int j = 0; j < size_n; j++){  
			        for(int x = 0; x < min_dim; x++){
			            vec[i][ pvec[j] ][x] += train_org[j][i * min_dim + x];	
			        }	
				    tol_count[ pvec[j] ]++;
		        }
			    
                for(int j = 0; j < L; j++){
					if(tol_count[j] == 0) continue; 
				    for(int l = 0; l < min_dim; l++){
					    vec[i][j][l] /= tol_count[j];
				    }

					float g = 0;					
					for(int l = 0; l < min_dim; l++){
					    g += vec[i][j][l] * vec[i][j][l];
					}
					for(int l = 0; l < min_dim; l++){
					    vec[i][j][l] = vec[i][j][l] / sqrt(g * max_book);
					}					
			    }
		    }
		
		    for(int j = 0; j < size_n; j++){
                for(int x = 0; x < min_dim; x++){
				    cvmSet (M_Y, i* min_dim + x, j, vec[i][pvec[j]][x]);
			    }
		    }	
	    }
		
        if(k1 == ROUND1 - 1) break;
	
        cvTranspose(M_Y, M_YT); // transpose

        if(k1 == 0)
        cvMatMul(M_X2, M_YT, ABt);
        else{ cvMatMul(M_RX, M_YT, ABt);}

	    cvSVD(ABt, ABt_D, ABt_U, ABt_VT, CV_SVD_V_T); //SVD
	    cvMatMul( ABt_U, ABt_VT, M_R );
	    cvTranspose(M_R, M_RT);
    	
	    if(k1 == 0){			
		    for (int i = 0; i < M_RC->rows; i++) {
                for (int j = 0; j < M_RC->cols; j++) {
				    if(i == j)
                        cvmSet (M_RC, i, j, 1);
			        else{
				        cvmSet (M_RC, i, j, 0);	
				    }
                }
            }
		    cvMatMul( PCA_R, M_RC, M_RC );	
	    }
      
        cvMatMul( M_RT, M_RC, M_RC );

	    cvMatMul( M_RC, M_X, M_RX );
           
        for(int i = 0; i < size_n; i++){
		    for(int j = 0; j < dim_; j++){
			    train_org[i][j] = cvmGet (M_RX, j, i);
				train_test[i][j] = cvmGet (M_RX, j, i);
		    }
	    }
	
	}
	
	for(int i = 0; i < max_book; i++){
		
		double min_real = 0.00000001;
		double max_real = 100000000;
		
		for(int j = 0; j < L; j++){
			float sum = 0;
            for(int l = 0; l < min_dim; l++)			
	            sum += vec[i][j][l] * vec[i][j][l]; 

	        if(sum > max_real || sum < min_real) {printf("error\n"); exit(0);}			       		
		}
	}
	
	float* R = new float [dim_ * dim_];
	
	for(int i = 0; i < dim_; i++){
		for(int j = 0; j < dim_; j++){ 
            R[i * dim_ + j] = cvmGet (M_RC, i, j);
		}
	}

#pragma omp parallel for	
    for (int i = 0; i < vecsize; i++) {
		appr_alg -> graph_rot(i, dim_, vecdim, R);
    }
   	    
    float** norm_vec = new float* [vecsize];
	unsigned char** sub_norm_arr = new unsigned char* [vecsize];
	for(int i = 0; i < vecsize; i++) {
		norm_vec[i] = new float[2 * M];	
		for(int j = 0; j < 2 * M; j++) norm_vec[i][j] = 0;
		sub_norm_arr[i] = new unsigned char[2 * M];
	}
	
    j1 = 0;
#pragma omp parallel for	
    for (int i = 0; i < vecsize; i++) {
		int j2=0;
#pragma omp critical
        {
            j1++;
            j2=j1;
			if(j1 % report_every == 0)
		        printf("GAQ construction...%.2f %% completed\n", (size_t) j1 * 100 / float(vecsize) );
            
	    }	
		appr_alg->PCA(i, vecdim, vec, dim_, norm_vec);
    }
		
	float cur_max = -1.0f;
	for(int i = 0; i < vecsize; i++){
		for(int j = 0; j < 2 * M; j++){
			if(norm_vec[i][j] > cur_max)
				cur_max = norm_vec[i][j];
		}
	}
	
	for(int i = 0; i < vecsize; i++){
		for(int j = 0; j < 2 * M; j++){
		    sub_norm_arr[i][j] = (unsigned char) (L * norm_vec[i][j] / cur_max);
		}
	}
			
	appr_alg->supplement(sub_norm_arr);
	
    cout << "training time:" << 1e-6 * stopw_train.getElapsedTimeMicro() << "  seconds\n";
	appr_alg->saveIndex(path_index);
		
    ofstream outputQ2("searching.bin", ios::binary);	
    outputQ2.write((char *) R, 4 * dim_ * dim_);
	
	outputQ2.write((char *) &cur_max, sizeof(float));
			
	for(int i = 0; i < max_book; i++){
		for(int j = 0; j < L; j++){
			outputQ2.write((char*) vec[i][j], 4 * min_dim);			
		}
    }
    outputQ2.close();		    	
    
    return;

}
