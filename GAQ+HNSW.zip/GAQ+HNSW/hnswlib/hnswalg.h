#pragma once

#include "visited_list_pool.h"
#include "hnswlib.h"
#include <random>
#include <stdlib.h>
#include <unordered_set>
#include <list>
#include <cmath>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/imgproc/imgproc.hpp"

//#define max_level_ 2
#define size_n 10000
#define L 256
#define sqrt_L 16
#define min_book 4

#define len_proj 2
#define max_book 16
#define sub_dim 16
//#define delta 0.5

using namespace cv;

struct elem{
	unsigned int id;
	float dist;
	bool flag;
};

namespace hnswlib {
    typedef unsigned int tableint;
    typedef unsigned int linklistsizeint;
	//typedef unsigned int labeltype;

    template<typename dist_t>
    class HierarchicalNSW : public AlgorithmInterface<dist_t> {
    public:
        HierarchicalNSW(SpaceInterface<dist_t> *s) {

        }

        HierarchicalNSW(SpaceInterface<dist_t> *s, const std::string &location,  bool nmslib = false, size_t max_elements=0) {
            loadIndex(location, s, max_elements);
        }

        HierarchicalNSW(SpaceInterface<dist_t> *s, size_t max_elements, int vecdim_, size_t M = 16, size_t ef_construction = 2000, size_t random_seed = 100) :
                link_list_locks_(max_elements), element_levels_(max_elements) { //check
            max_elements_ = max_elements;

			vecdim = vecdim_;
            has_deletions_=false;
            data_size_ = s->get_data_size();
            fstdistfunc_ = s->get_dist_func();
            dist_func_param_ = s->get_dist_func_param();
			dist_func_param2_ = s->get_dist_func_param2();
			
            M_ = M;
            maxM_ = M_;
			maxM0_ = 2 * M_;
			
            ef_construction_ = std::max(ef_construction,M_);
            ef_ = 10;

            level_generator_.seed(random_seed);
			
            size_proj_level0_ = sizeof(float) + sub_dim * sizeof(float) + sub_dim * max_book * sizeof(unsigned char) + 
			     maxM0_ * sizeof(unsigned char) * ( 1 + sub_dim / len_proj);
            size_proj_per_element_ = max_book;
            size_base_per_element_ = sub_dim * sizeof(float);
            offsetBase_ = sizeof(float);
            offsetProj_ = sizeof(float) + sub_dim * sizeof(float);	
            offsetVec_ =  sizeof(float) + sub_dim * sizeof(float) + sub_dim * max_book * sizeof(unsigned char);			

					
            size_links_level0_ = maxM0_ * sizeof(tableint) + sizeof(linklistsizeint);			
            size_data_per_element_ =  size_proj_level0_ + size_links_level0_ + sizeof(float) + data_size_ + sizeof(labeltype);
							
            offsetLevel0_ = size_proj_level0_;		
			offsetNorm_= size_proj_level0_ + size_links_level0_;
            offsetData_ = size_proj_level0_ + sizeof(float) + size_links_level0_;
            label_offset_ = size_proj_level0_ + size_links_level0_ + sizeof(float) + data_size_;
		
            data_level0_memory_ = (char *) malloc(max_elements_ * size_data_per_element_);
            if (data_level0_memory_ == nullptr)
                throw std::runtime_error("Not enough memory");

            cur_element_count = 0;

            visited_list_pool_ = new VisitedListPool(1, max_elements);

            enterpoint_node_ = -1;
            linkLists_ = (char **) malloc(sizeof(void *) * max_elements_);
            if (linkLists_ == nullptr)
                throw std::runtime_error("Not enough memory: HierarchicalNSW failed to allocate linklists");
            size_links_per_element_ = maxM_ * sizeof(tableint) + sizeof(linklistsizeint);
            mult_ = 1 / log(1.0 * M_);
            revSize_ = 1.0 / mult_;
			count0 = 0;
        }

        struct Neighbor0 {
            unsigned id;
            float distance;
       	
            Neighbor0() = default;
            Neighbor0(unsigned id, float distance) : id{id}, distance{distance} {}

            inline bool operator<(const Neighbor0 &other) const {
                return distance < other.distance;
            }
        };

        static inline int InsertIntoPool0 (Neighbor0 *addr, unsigned K, Neighbor0 nn) {
            // find the location to insert
            int left=0,right=K-1;
            if(addr[left].distance>nn.distance){
                memmove((char *)&addr[left+1], &addr[left],K * sizeof(Neighbor0));
                addr[left] = nn;
                return left;
            }
            if(addr[right].distance<nn.distance){
                addr[K] = nn;
                return K;
            }
            while(left<right-1){
                int mid=(left+right)/2;
                if(addr[mid].distance>nn.distance)right=mid;
                else left=mid;
            }

            while (left > 0){
                if (addr[left].distance < nn.distance) break;
                if (addr[left].id == nn.id) return K + 1;
                left--;
            }
            if(addr[left].id == nn.id||addr[right].id==nn.id)return K+1;
            memmove((char *)&addr[right+1], &addr[right],(K-right) * sizeof(Neighbor0));
            addr[right]=nn;
            return right;
        }

        struct Neighbor {
            unsigned id;
            float distance;
            bool flag;
            bool flag2;
	
            Neighbor() = default;
            Neighbor(unsigned id, float distance, bool f, bool f2) : id{id}, distance{distance}, flag(f), flag2(f2) {}

            inline bool operator<(const Neighbor &other) const {
                return distance < other.distance;
            }
        };

        static inline int InsertIntoPool (Neighbor *addr, unsigned K, Neighbor nn) {
		
            int left=0,right=K-1;
            if(addr[left].distance>nn.distance){
                memmove((char *)&addr[left+1], &addr[left],K * sizeof(Neighbor));
                addr[left] = nn;
                return left;
            }
            if(addr[right].distance<nn.distance){
                addr[K] = nn;
                return K;
            }
            while(left<right-1){
                int mid=(left+right)/2;
                if(addr[mid].distance>nn.distance)right=mid;
                else left=mid;
            }
 
            while (left > 0){
                if (addr[left].distance < nn.distance) break;
                if (addr[left].id == nn.id) return K + 1;
                left--;
            }
            if(addr[left].id == nn.id||addr[right].id==nn.id)return K+1;
            memmove((char *)&addr[right+1], &addr[right],(K-right) * sizeof(Neighbor));
            addr[right]=nn;
            return right;
        }

        struct CompareByFirst {
            constexpr bool operator()(std::pair<dist_t, tableint> const &a,
                                      std::pair<dist_t, tableint> const &b) const noexcept {
                return a.first < b.first;
            }
        };

        ~HierarchicalNSW() {    

            free(data_level0_memory_);
            for (tableint i = 0; i < max_elements_; i++) {
                if (element_levels_[i] > 0)
                    free(linkLists_[i]);
            }
            free(linkLists_);
            delete visited_list_pool_;
        }

        size_t max_elements_;
        size_t cur_element_count;
        size_t size_data_per_element_;
        size_t size_links_per_element_;
        size_t size_proj_level0_;

        size_t size_proj_per_element_;
        size_t size_base_per_element_;

        size_t M_;
        size_t maxM_;
        size_t maxM0_;
		
        size_t ef_construction_;
        double mult_, revSize_;
        int maxlevel_;
		
		int vecdim;
        int count0;		

        VisitedListPool *visited_list_pool_;
        std::mutex cur_element_count_guard_;

        std::vector<std::mutex> link_list_locks_;
        tableint enterpoint_node_;

        size_t size_links_level0_;
        size_t offsetNorm_, offsetData_, offsetLevel0_;

        size_t offsetBase_, offsetProj_, offsetVec_;

        char *data_level0_memory_;
        char **linkLists_;
        std::vector<int> element_levels_;

        size_t data_size_;

        bool has_deletions_;


        size_t label_offset_;
        DISTFUNC<dist_t> fstdistfunc_;
        void *dist_func_param_;
		void *dist_func_param2_;
		
        std::unordered_map<labeltype, tableint> label_lookup_;

        std::default_random_engine level_generator_;

        inline labeltype getExternalLabel(tableint internal_id) const {
            labeltype return_label;
            memcpy(&return_label,(data_level0_memory_ + internal_id * size_data_per_element_ + label_offset_), sizeof(labeltype));	
            return return_label;
        }

        inline void setExternalLabel(tableint internal_id, labeltype label) const {
            memcpy((data_level0_memory_ + internal_id * size_data_per_element_ + label_offset_), &label, sizeof(labeltype));
        }

        inline labeltype *getExternalLabeLp(tableint internal_id) const {
            return (labeltype *) (data_level0_memory_ + internal_id * size_data_per_element_ + label_offset_);
        }

        inline char *getDataByInternalId(tableint internal_id) const {
            return (data_level0_memory_ + internal_id * size_data_per_element_ + offsetData_);
        }
		
        inline float getNormByInternalId(tableint internal_id) const {
		    return  *( (float *) (data_level0_memory_ + internal_id * size_data_per_element_ + offsetNorm_) );
        }	

        inline char *getNormByInternalId2(tableint internal_id) const {
		    return (data_level0_memory_ + internal_id * size_data_per_element_ + offsetNorm_);
        }

        inline char *getBaseByInternalId(tableint internal_id) const {
		    return (data_level0_memory_ + internal_id * size_data_per_element_ + offsetBase_);
        }
		
        inline char *getProjByInternalId(tableint internal_id) const {
		    return (data_level0_memory_ + internal_id * size_data_per_element_ + offsetProj_);
        }		
     
        inline char *getVecByInternalId(tableint internal_id) const {
		    return (data_level0_memory_ + internal_id * size_data_per_element_ + offsetVec_);
        }		 

        int getRandomLevel(double reverse_size) {
            std::uniform_real_distribution<double> distribution(0.0, 1.0);
            double r = -log(distribution(level_generator_)) * reverse_size;
            return (int) r;
        }

        float compare_(const float* a, const float* b, unsigned size) const { // !unchecked
			float result = 0;
			float diff0, diff1, diff2, diff3;
            const float* last = a + size;
            const float* unroll_group = last - 3;

            /* Process 4 items with each loop for efficiency. */
            while (a < unroll_group) {
                diff0 = a[0] * b[0];
                diff1 = a[1] * b[1];
                diff2 = a[2] * b[2];
                diff3 = a[3] * b[3];
                result += diff0 + diff1 + diff2 + diff3;
                a += 4;
                b += 4;
            }
            /* Process last 0-3 pixels.  Not needed for standard vector lengths. */
            while (a < last) {
                diff0 = (*a++) * (*b++);
                result += diff0;
            }
            return result;
        }
		
		void rotation_(int vecsize, int dim_, float** data, float* R){  //not use
			
                    #pragma omp parallel for		
			for(int i = 0; i < vecsize; i++){
                            float* data3 = new float[dim_]; 
		        for(int j = 0; j < dim_; j++){
			        data3[j] = 0;
				    data3[j] = fstdistfunc_( (const void*) (R + j * dim_), (const void*) (data[i]), dist_func_param2_);				        
		        }
		
		        for(int l = 0; l < dim_; l++){
			        data[i][l] = data3[l];
		        }
				delete[] data3;
	        }			
		}
		
		void graph_rot(int cur_id, int dim_, int vecdim_, float* R){
			float* data = (float *) getDataByInternalId(cur_id);
			float* data3 = new float[dim_]; 
		    for(int j = 0; j < dim_; j++){
				data3[j] = fstdistfunc_( (const void*) (R + j * dim_), (const void*) (data), dist_func_param2_);	
			        
		    }			
			memcpy(data, data3, sizeof(float) * vecdim_);
			delete[] data3;
		}		
			

        void restore_index(float *query_data, float* array0, float* book, int sdim, int tol_dim){ //!unchecked
            float* temp_arr2 = new float[sdim];

            int base_dim = sdim;
		
	        float* ind2 = array0 ;
			
	        for(int j = 0; j < base_dim; j++){
		        temp_arr2[j] = fstdistfunc_( (const void*) ind2, (const void*) query_data, dist_func_param_);
                ind2 += tol_dim;			
	        }   
 
	        for(int j = 0; j < L; j++){
		        _mm_prefetch(ind2, _MM_HINT_T0);

		        book[j] = compare_(ind2, temp_arr2, base_dim);

	            ind2 += base_dim;		
	        }
           	
        }

        std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst>		
        searchBaseLayer(tableint ep_id, const void *data_point, float temp_norm, int layer) {
            VisitedList *vl = visited_list_pool_->getFreeVisitedList();
            vl_type *visited_array = vl->mass;
            vl_type visited_array_tag = vl->curV;

            std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> top_candidates;
            std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> candidateSet;

            dist_t lowerBound;
			dist_t dist;
			dist_t dist1;
			
            dist = temp_norm + getNormByInternalId(ep_id) - 2 * fstdistfunc_(data_point, getDataByInternalId(ep_id), dist_func_param_);
		
            top_candidates.emplace(dist, ep_id);
            lowerBound = dist;
            candidateSet.emplace(-dist, ep_id);

            visited_array[ep_id] = visited_array_tag;

            while (!candidateSet.empty()) {
                std::pair<dist_t, tableint> curr_el_pair = candidateSet.top();
                if ((-curr_el_pair.first) > lowerBound) {
                    break;
                }
                candidateSet.pop();

                tableint curNodeNum = curr_el_pair.second;

                std::unique_lock <std::mutex> lock(link_list_locks_[curNodeNum]);

                int *data;// = (int *)(linkList0_ + curNodeNum * size_links_per_element0_);
				
                if (layer == 0) {
                    data = (int*)get_linklist0(curNodeNum);
                } else {
                    data = (int*)get_linklist(curNodeNum, layer);
                }
                size_t size = getListCount((linklistsizeint*)data);
                tableint *datal = (tableint *) (data + 1);
				
                for (size_t j = 0; j < size; j++) {
                    tableint candidate_id = *(datal + j);

                    if (visited_array[candidate_id] == visited_array_tag) continue;
                    visited_array[candidate_id] = visited_array_tag;
                    //char *currObj1 = (getDataByInternalId(candidate_id, level));

                    dist1 = temp_norm + getNormByInternalId(candidate_id) - 2 * fstdistfunc_(data_point, getDataByInternalId(candidate_id), dist_func_param_);
					
                    if (top_candidates.size() < ef_construction_ || lowerBound > dist1) {
                        candidateSet.emplace(-dist1, candidate_id);

                            top_candidates.emplace(dist1, candidate_id);

                        if (top_candidates.size() > ef_construction_)
                            top_candidates.pop();

                        if (!top_candidates.empty())
                            lowerBound = top_candidates.top().first;
                    }
                }
            }
            visited_list_pool_->releaseVisitedList(vl);

            return top_candidates;
        }

        void getNeighborsByHeuristic2(
                std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> &top_candidates,
                const size_t M) {
            if (top_candidates.size() < M) {
                return;
            }
            std::priority_queue<std::pair<dist_t, tableint>> queue_closest;
            std::vector<std::pair<dist_t, tableint>> return_list;
            while (top_candidates.size() > 0) {
                queue_closest.emplace(-top_candidates.top().first, top_candidates.top().second);
                top_candidates.pop();
            }
            dist_t curdist;
            while (queue_closest.size()) {
                if (return_list.size() >= M)
                    break;
                std::pair<dist_t, tableint> curent_pair = queue_closest.top();
                dist_t dist_to_query = -curent_pair.first;
                queue_closest.pop();
                bool good = true;
                for (std::pair<dist_t, tableint> second_pair : return_list) {
					
                    curdist =
                            getNormByInternalId(second_pair.second) + getNormByInternalId(curent_pair.second) - 2 *
							             fstdistfunc_(getDataByInternalId(second_pair.second),
                                         getDataByInternalId(curent_pair.second),
                                         dist_func_param_); //two 
										 					 
										 
                    if (curdist < dist_to_query) {
                        good = false;
                        break;
                    }
                }
                if (good) {
                    return_list.push_back(curent_pair);
                }


            }

            for (std::pair<dist_t, tableint> curent_pair : return_list) {

                top_candidates.emplace(-curent_pair.first, curent_pair.second);
            }
        }


        linklistsizeint *get_linklist0(tableint internal_id) const {
            return (linklistsizeint *) (data_level0_memory_ + internal_id * size_data_per_element_ + offsetLevel0_);
        };

        linklistsizeint *get_linklist(tableint internal_id, int level) const {
            return (linklistsizeint *) (linkLists_[internal_id] + (level - 1) * size_links_per_element_);
        };

        void mutuallyConnectNewElement(const void *data_point, tableint cur_c,
                                       std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> top_candidates,
                                       int level) {

            size_t Mcurmax;			
			Mcurmax = level ? maxM_ : maxM0_;

            getNeighborsByHeuristic2(top_candidates, M_);
            if (top_candidates.size() > M_)
                throw std::runtime_error("Should be not be more than M_ candidates returned by the heuristic");

            std::vector<tableint> selectedNeighbors;
            selectedNeighbors.reserve(M_);
            while (top_candidates.size() > 0) {
                selectedNeighbors.push_back(top_candidates.top().second);
                top_candidates.pop();
            }

            {
                linklistsizeint *ll_cur;
                if (level == 0)
                    ll_cur = get_linklist0(cur_c);
                else
                    ll_cur = get_linklist(cur_c, level);

                if (*ll_cur) {
                    throw std::runtime_error("The newly inserted element should have blank link list");
                }
                setListCount(ll_cur,selectedNeighbors.size());
                tableint *data = (tableint *) (ll_cur + 1);


                for (size_t idx = 0; idx < selectedNeighbors.size(); idx++) {
                    if (data[idx])
                        throw std::runtime_error("Possible memory corruption");
                    if (level > element_levels_[selectedNeighbors[idx]])
                        throw std::runtime_error("Trying to make a link on a non-existent level");

                    data[idx] = selectedNeighbors[idx];

                }
            }
			dist_t d_max;
            for (size_t idx = 0; idx < selectedNeighbors.size(); idx++) {

                std::unique_lock <std::mutex> lock(link_list_locks_[selectedNeighbors[idx]]);
                
                linklistsizeint *ll_other;
                if (level == 0)
                    ll_other = get_linklist0(selectedNeighbors[idx]);
                else
                    ll_other = get_linklist(selectedNeighbors[idx], level);

                size_t sz_link_list_other = getListCount(ll_other);

                if (sz_link_list_other > Mcurmax)
                    throw std::runtime_error("Bad value of sz_link_list_other");
                if (selectedNeighbors[idx] == cur_c)
                    throw std::runtime_error("Trying to connect an element to itself");
                if (level > element_levels_[selectedNeighbors[idx]])
                    throw std::runtime_error("Trying to make a link on a non-existent level");

                tableint *data = (tableint *) (ll_other + 1);
                if (sz_link_list_other < Mcurmax) {
                    data[sz_link_list_other] = cur_c;
                    setListCount(ll_other, sz_link_list_other + 1);
                } else {
                    // finding the "weakest" element to replace it with the new one
                        d_max =  getNormByInternalId(cur_c) + getNormByInternalId(selectedNeighbors[idx]) - 2 * 
					            fstdistfunc_(getDataByInternalId(cur_c), getDataByInternalId(selectedNeighbors[idx]),
                                                dist_func_param_);					
                    // Heuristic:
                    std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> candidates;
                    candidates.emplace(d_max, cur_c);

                    for (size_t j = 0; j < sz_link_list_other; j++) {
                        candidates.emplace(
					            getNormByInternalId(data[j]) + getNormByInternalId(selectedNeighbors[idx]) - 2 *
                                fstdistfunc_(getDataByInternalId(data[j]), getDataByInternalId(selectedNeighbors[idx]),
                                             dist_func_param_), data[j]);						
                    }

                    getNeighborsByHeuristic2(candidates, Mcurmax);

                    int indx = 0;
                    while (candidates.size() > 0) {
                        data[indx] = candidates.top().second;
                        candidates.pop();
                        indx++;
                    }
                    setListCount(ll_other, indx);
                    // Nearest K:
                    /*int indx = -1;
                    for (int j = 0; j < sz_link_list_other; j++) {
                        dist_t d = fstdistfunc_(getDataByInternalId(data[j]), getDataByInternalId(rez[idx]), dist_func_param_);
                        if (d > d_max) {
                            indx = j;
                            d_max = d;
                        }
                    }
                    if (indx >= 0) {
                        data[indx] = cur_c;
                    } */
                }

            }
        }

        std::mutex global;
        size_t ef_;

        void setEf(size_t ef) {
            ef_ = ef;
        }
		
		void find_neighbors(size_t vecdim_, float** train_org, int ind, int* count, float** data){ //check
		
		    float min_real = 0.000001;
			int true_id = getExternalLabel(ind);
		    unsigned *neighbors = (unsigned *)(data_level0_memory_ + size_data_per_element_ * ind + offsetLevel0_);
	  
            unsigned MaxM = *neighbors;
            neighbors++;
			
			for(int i = 0; i < MaxM; i++){
				int obj_id = getExternalLabel(neighbors[i]);
				float sum = 0;
				for(int j = 0; j < vecdim_; j++){
					train_org[*count][j] = data[obj_id][j] - data[true_id][j];
                    sum += train_org[*count][j] * train_org[*count][j];					
				}
				
				if (sum < min_real) continue; 
				
				for(int j = 0; j < vecdim_; j++){
					train_org[*count][j] = train_org[*count][j] / sqrt(sum);				
				}				
				
				(*count)++;
				if( *count >= size_n ) break;
			}
		}
				
		void supplement(unsigned char** norm_vec){

			for(int i = 0; i < max_elements_; i++){
				linklistsizeint* ll_other = get_linklist0(i);
				int sz_link_list_other = getListCount(ll_other);
				
			    int sub_dim0 = sub_dim;
			    if(sz_link_list_other < sub_dim) {
				
				
				    if(sz_link_list_other % 2 == 0){
					    sub_dim0 = sz_link_list_other;				    	
				    }
				    else{
					    sub_dim0 = sz_link_list_other - 1;
				    }
			    }				
						
				if(sz_link_list_other <= 1) continue;
				unsigned char* proj_vec = (unsigned char*) getVecByInternalId(i);
				
				for(int j = 0; j < sz_link_list_other; j++){
				    memcpy(proj_vec, &(norm_vec[i][j]), 1);				
				    proj_vec += (1 + sub_dim0 / 2);
				}	
			}
			
		}
		
        void PCA(int cur_id, int vecdim_, float*** vec, int dim, float** norm_vec){
			int min_dim =  dim / max_book;
			double PI = 3.14159265358979323;
            float* base_vec  = (float *) getDataByInternalId(cur_id);
			
			linklistsizeint *ll_other;
			ll_other = get_linklist0(cur_id);
		    int sz_link_list_other = getListCount(ll_other);
			
			int sub_dim0 = sub_dim;
			if(sz_link_list_other < sub_dim) {

				if(sz_link_list_other <= 1){
					char* loc0 = data_level0_memory_ + size_data_per_element_ * cur_id;
			        memcpy(loc0, &sz_link_list_other, sizeof(linklistsizeint));   //write MaxM	
				    return;				
				}
					
				if(sz_link_list_other % 2 == 0){
					sub_dim0 = sz_link_list_other;				    	
				}
				else{
					sub_dim0 = sz_link_list_other - 1;
				}
			}

            tableint *data = (tableint *) (ll_other + 1);
			
			float** obj_vec = new float* [sz_link_list_other];
			
			for(int j = 0; j < sz_link_list_other; j++)
				obj_vec[j] = new float[vecdim_];
			
            for (size_t j = 0; j < sz_link_list_other; j++) { 			
                tableint a= data[j];
				float* cur_vec = (float *) getDataByInternalId(a);
				
				for (size_t l = 0; l < vecdim_; l++)
				    obj_vec[j][l] = cur_vec[l] - base_vec[l];
				
			}
			
			CvMat* M_X = cvCreateMat(sz_link_list_other, vecdim_, CV_32FC1);
			for (int l = 0; l < M_X->rows; l++) {
                for (int j = 0; j < M_X->cols; j++) {
                    cvmSet (M_X, l, j, obj_vec[l][j]);
                }
            }
					
	        CvMat* pMean = cvCreateMat(1, vecdim_, CV_32FC1);
	        CvMat* pEigVals = cvCreateMat(1, sz_link_list_other, CV_32FC1);
	        CvMat* pEigVecs = cvCreateMat(sz_link_list_other, vecdim_, CV_32FC1);
	        cvCalcPCA(M_X, pMean, pEigVals, pEigVecs, CV_PCA_DATA_AS_ROW);
			
	        CvMat* M_axe = cvCreateMat(sub_dim0, vecdim_, CV_32FC1);

	        float* pca_arr = new float[vecdim_];
	        float ssum = 0;
	        for(int i = 0; i < sub_dim0; i++){
	            for(int j = 0; j < vecdim_; j++){
	                pca_arr[j] = cvmGet(pEigVecs, i, j);
		        }
				
				for(int j = 0; j < vecdim_; j++){
		            cvmSet(M_axe, i, j, pca_arr[j]);
		        }
	        }
			delete[] pca_arr;  

            cvReleaseMat(&pMean);
            cvReleaseMat(&pEigVals);
            cvReleaseMat(&pEigVecs); 

	        unsigned char** proj_id = new unsigned char* [sub_dim0];
			for(int i = 0; i < sub_dim0; i++){
				proj_id[i] = new unsigned char[max_book];
			}
		    float* pca_arr2 = new float[sub_dim0];
	       
			for (int l = 0; l < M_X->rows; l++) {
                for (int j = 0; j < M_X->cols; j++) {
                    cvmSet (M_X, l, j, obj_vec[l][j]);
                }
            }
			
			for(int j = 0; j < sz_link_list_other; j++)
				delete[] obj_vec[j];
			
			delete[] obj_vec;

            int round = 3;
			float temp, max_temp;
			unsigned char min_vec = 0;
			unsigned char min_vec2 = 0;
			
			CvMat* M_Q = cvCreateMat(vecdim_, sub_dim0, CV_32FC1);
			CvMat* M_R = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
			CvMat* M_Y = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
			CvMat* M_YT = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
	
	        CvMat* ABt   = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
	        CvMat* ABt_D = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
	        CvMat* ABt_U = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);
	        CvMat* ABt_VT = cvCreateMat(sub_dim0, sub_dim0, CV_32FC1);			
						
			float test_sum = 0;
            for(int k = 0; k < round; k++){
			    for(int i = 0; i < max_book; i++){
		            for(int j = 0; j < sub_dim0; j++){  //assignment of train vectors	---sub_dim		
			            for(int l = 0; l < L; l++){
				            temp = 0;
                            for(int x = 0; x < min_dim; x++){
			                    temp += (cvmGet(M_axe, j, i * min_dim + x) * vec[i][l][x]);
                            }
						
						    if( l == 0) {max_temp = temp; min_vec = l;}
                            else if(temp > max_temp) {max_temp = temp; min_vec = l;}				
		                }
						
				        if(k == round - 1)
						    proj_id[j][i] = min_vec;
				
                        for(int x = 0; x < min_dim; x++)
                           cvmSet(M_Q, i * min_dim + x, j, vec[i][min_vec][x]);				
		            }
			    }
				

			    if(k == round - 1){
				    char* proj_vec = getProjByInternalId(cur_id);
				    for(int i = 0; i < sub_dim0; i++){
				        memcpy(proj_vec, proj_id[i], size_proj_per_element_);
					    proj_vec += size_proj_per_element_;
				    }	 
				    break;
			    }
			
			    cvMatMul(M_axe, M_Q, M_Y);   
							
	            for(int i = 0; i < sub_dim0; i++){    
	                for(int j = 0; j < sub_dim0; j++){
	                    pca_arr2[j] = cvmGet(M_Y, j, i);
		            }
				
		            ssum = 0;
		            for(int j = 0; j < sub_dim0; j++){
			            ssum += pca_arr2[j] * pca_arr2[j];
		            }
				
		            for(int j = 0; j < sub_dim0; j++){
		                cvmSet(M_Y, j, i, pca_arr2[j]/sqrt(ssum));
		            }
	            }			
			
			    cvTranspose(M_Y, M_YT);
	            cvSVD(M_YT, ABt_D, ABt_U, ABt_VT, CV_SVD_V_T); //SVD
	            cvMatMul( ABt_U, ABt_VT, M_R );
				cvMatMul(M_R, M_axe, M_axe);
			}	

			for(int i = 0; i < sub_dim0; i++){
	            for(int j = 0; j < vecdim_; j++){
					cvmSet(M_axe, i, j, cvmGet(M_Q, j, i) );
				}
			}
			cvReleaseMat(&M_Q);
			cvReleaseMat(&M_R);
			cvReleaseMat(&M_Y);
			cvReleaseMat(&M_YT);
			
			cvReleaseMat(&ABt);
			cvReleaseMat(&ABt_D);
			cvReleaseMat(&ABt_U);
			cvReleaseMat(& ABt_VT);			
			
			delete[] pca_arr2;
			for(int i = 0; i < sub_dim0; i++){
				delete[] proj_id[i];
			}
   			delete[] proj_id;
			
			CvMat* M_Z = cvCreateMat(sub_dim0, sz_link_list_other, CV_32FC1);
			CvMat* M_B = cvCreateMat(vecdim_, 1, CV_32FC1);
			CvMat* M_B0 = cvCreateMat(sub_dim0, 1, CV_32FC1);
			for(int i = 0; i < vecdim_; i++)
				cvmSet( M_B, i, 0, base_vec[i] );
		
		
			CvMat* M_XT = cvCreateMat(vecdim_, sz_link_list_other, CV_32FC1);
			cvTranspose(M_X, M_XT);		
			cvMatMul(M_axe, M_XT, M_Z);	
			cvMatMul(M_axe, M_B, M_B0);

		    cvReleaseMat(&M_axe);
			cvReleaseMat(&M_B);
			cvReleaseMat(&M_X);
			cvReleaseMat(&M_XT);	
			
			float* tmp_arr = new float[sub_dim0];
			for(int i = 0; i < sub_dim0; i++)
				tmp_arr[i] = cvmGet(M_B0, i, 0);  
										
			cvReleaseMat(&M_B0);
			
			char* loc = data_level0_memory_ + size_data_per_element_ * cur_id;
			memcpy(loc, &sz_link_list_other, sizeof(linklistsizeint));   //write MaxM
			
			memcpy(getBaseByInternalId(cur_id), (char *)tmp_arr, sub_dim0 * sizeof(float)); //write base vector
		    
			delete[] tmp_arr;
		
			char* proj_vec = getVecByInternalId(cur_id);
			unsigned char* proj_pos = new unsigned char[sub_dim0 / 2];
		
			for(int i = 0; i < sz_link_list_other; i++){
				
				norm_vec[cur_id][i] = 0;
				for(int j = 0; j < sub_dim0; j++)
				    norm_vec[cur_id][i] += cvmGet(M_Z, j, i) * cvmGet(M_Z, j, i);
				
				norm_vec[cur_id][i] = sqrt(norm_vec[cur_id][i]);

				for(int j = 0; j < sub_dim0; j++)
				    cvmSet(M_Z, j, i, cvmGet(M_Z, j, i) / norm_vec[cur_id][i]);
					
				proj_vec++;
				
				float test0 = 0;
		        for(int j = 0; j < sub_dim0 / 2; j++){
					float x_axis = cvmGet(M_Z, 2 * j, i);
			        float y_axis = cvmGet(M_Z, 2 * j + 1, i);
					
					ssum = sqrt( x_axis * x_axis + y_axis * y_axis);
					float inval_ = 1.0 / (sqrt_L + 1);
					
					for(int ii = 0; ii < sqrt_L; ii++){
						temp = fabs( (ii + 1) * inval_ - ssum );
						if(ii == 0) {min_vec = 0; max_temp = temp;}
						else{
							if(temp < max_temp){
								max_temp = temp;
								min_vec = ii;
							}
						}
					}
										
					float angle = 0;
					if( x_axis == 0 && y_axis > 0) {
						angle = PI / 2;
					}
					else if( x_axis == 0 && y_axis < 0 ){
						angle = 3 * PI / 2;
					}
					
					if(x_axis != 0){
					    angle = atan(y_axis / x_axis);
					    
						if(x_axis < 0) angle += PI; 
					    else if( x_axis > 0 && y_axis < 0 ) angle += 2 * PI;

					}
										
					inval_ = 360.0 / sqrt_L;
					ssum = 360.0 * angle / (2 * PI);
					for(int ii = 0; ii < sqrt_L; ii++){
						temp = fabs( ii * inval_ - ssum );
						if(ii == 0) {min_vec2 = 0; max_temp = temp;}
						else{
							if(temp < max_temp){
								max_temp = temp;
								min_vec2 = ii;
							}
						}
					}
	
                    proj_pos[j] = (unsigned char) ( min_vec * sqrt_L + min_vec2);					
     			}
							
				memcpy(proj_vec, proj_pos, sub_dim0 / 2);				
				proj_vec += sub_dim0 / 2;
			}
			delete[] proj_pos;
            cvReleaseMat(&M_Z);			
		}
			
        void saveIndex(const std::string &location) {
            std::ofstream output(location, std::ios::binary);
            std::streampos position;

            writeBinaryPOD(output, max_elements_);		
            writeBinaryPOD(output, maxM_);
            writeBinaryPOD(output, maxM0_);

            writeBinaryPOD(output, maxlevel_);
            writeBinaryPOD(output, enterpoint_node_);
            writeBinaryPOD(output, M_);
            writeBinaryPOD(output, mult_);
            writeBinaryPOD(output, ef_construction_);

            output.write(data_level0_memory_, max_elements_ * size_data_per_element_);
			
            for (size_t i = 0; i < max_elements_; i++) {
                unsigned int linkListSize = element_levels_[i] > 0 ? size_links_per_element_ * element_levels_[i] : 0;
                writeBinaryPOD(output, linkListSize);
                if (linkListSize)
                    output.write(linkLists_[i], linkListSize);
            }
			
            output.close();
        }

        void loadIndex(const std::string &location, SpaceInterface<dist_t> *s, size_t max_elements_i=0) {

            std::ifstream input(location, std::ios::binary);
          
            readBinaryPOD(input, max_elements_);
			
			 size_t max_elements=max_elements_;

            readBinaryPOD(input, maxM_);
            readBinaryPOD(input, maxM0_);
			
            readBinaryPOD(input, maxlevel_);
            readBinaryPOD(input, enterpoint_node_);			
            readBinaryPOD(input, M_);
            readBinaryPOD(input, mult_);
            readBinaryPOD(input, ef_construction_);
     
            data_size_ = s->get_data_size();
            fstdistfunc_ = s->get_dist_func();
            dist_func_param_ = s->get_dist_func_param();			
			
            size_proj_level0_ = sizeof(float) + sub_dim * sizeof(float) + sub_dim * max_book * sizeof(unsigned char) + 
			maxM0_ * sizeof(unsigned char) * ( 1 + sub_dim / len_proj);
            size_proj_per_element_ = max_book;
            size_base_per_element_ = sub_dim * sizeof(float);
            offsetBase_ = sizeof(float);
            offsetProj_ = sizeof(float) + sub_dim * sizeof(float);	
            offsetVec_ =  sizeof(float) + sub_dim * sizeof(float) + sub_dim * max_book * sizeof(unsigned char);			
	
            size_links_level0_ = maxM0_ * sizeof(tableint) + sizeof(linklistsizeint);			
            size_data_per_element_ =  size_proj_level0_ + size_links_level0_ + sizeof(float) + data_size_ + sizeof(labeltype);
			
            offsetLevel0_ = size_proj_level0_;		
			offsetNorm_= size_proj_level0_ + size_links_level0_;
            offsetData_ = size_proj_level0_ + sizeof(float) + size_links_level0_;
            label_offset_ = size_proj_level0_ + size_links_level0_ + sizeof(float) + data_size_;
			
			size_links_per_element_ = maxM_ * sizeof(tableint) + sizeof(linklistsizeint);

            data_level0_memory_ = (char *) malloc(max_elements_ * size_data_per_element_);
            if (data_level0_memory_ == nullptr)
                throw std::runtime_error("Not enough memory: loadIndex failed to allocate level0");
            input.read(data_level0_memory_, max_elements_ * size_data_per_element_);

            if (!input.is_open())
                throw std::runtime_error("Cannot open file");
				
            std::vector<std::mutex>(max_elements).swap(link_list_locks_);
			
            visited_list_pool_ = new VisitedListPool(1, max_elements);
	
            linkLists_ = (char **) malloc(sizeof(void *) * max_elements);
            if (linkLists_ == nullptr)
                throw std::runtime_error("Not enough memory: loadIndex failed to allocate linklists");	

			
            element_levels_ = std::vector<int>(max_elements);
            revSize_ = 1.0 / mult_;
            ef_ = 10;
			
            for (size_t i = 0; i < max_elements_; i++) {

                label_lookup_[getExternalLabel(i)]=i;
                unsigned int linkListSize;
                readBinaryPOD(input, linkListSize);
								
                if (linkListSize == 0) {
                    element_levels_[i] = 0;

                    linkLists_[i] = nullptr;
                } else {
                    element_levels_[i] = linkListSize / size_links_per_element_;
                    linkLists_[i] = (char *) malloc(linkListSize);
                    if (linkLists_[i] == nullptr)
                        throw std::runtime_error("Not enough memory: loadIndex failed to allocate linklist");
                    input.read(linkLists_[i], linkListSize);
                }
            }

            has_deletions_=false;
            input.close();
            return;
        }

 //       static const unsigned char DELETE_MARK = 0x01;
//        static const unsigned char REUSE_MARK = 0x10;
        /**
         * Marks an element with the given label deleted, does NOT really change the current graph.
         * @param label
         */
        void markDelete(labeltype label)
        {

        }

        /**
         * Uses the first 8 bits of the memory for the linked list to store the mark,
         * whereas maxM0_ has to be limited to the lower 24 bits, however, still large enough in almost all cases.
         * @param internalId
         */
        void markDeletedInternal(tableint internalId) {

        }

        /**
         * Remove the deleted mark of the node.
         * @param internalId
         */
        void unmarkDeletedInternal(tableint internalId) {

        }

        /**
         * Checks the first 8 bits of the memory to see if the element is marked deleted.
         * @param internalId
         * @return
         */
        bool isMarkedDeleted(tableint internalId) const {

        }

        unsigned short int getListCount(linklistsizeint * ptr) const {
            return *((unsigned short int *)ptr);
        }

        void setListCount(linklistsizeint * ptr, unsigned short int size) const {
            *((unsigned short int*)(ptr))=*((unsigned short int *)&size);
        }

        void addPoint(const void *data_point, labeltype label, bool flag) {
		addPoint(data_point, label, -1, flag);
        }
			
		float querydistfunc_(unsigned char* id, int num, float** book) const{
			float dist = 0;

			float diff0, diff1, diff2, diff3;
            const unsigned char* last = id + num;
            const unsigned char* unroll_group = last - 3;
			int x = 0;
            /* Process 4 items with each loop for efficiency. */
            while (id < unroll_group) {
				
                diff0 = book[x][id[0]];
                diff1 = book[x+1][id[1]];
                diff2 = book[x+2][id[2]];
                diff3 = book[x+3][id[3]];
                dist += diff0 + diff1 + diff2 + diff3;
                id += 4;
				x += 4;
            } 
            return dist;			
			
		}
		
        tableint addPoint(const void *data_point, labeltype label, int level, bool flag) {	
		    tableint cur_c = 0;
			dist_t curdist;
			if(flag == true){   
                enterpoint_node_ = -1;
                maxlevel_ = -1;
			    count0 = 0;
				if(visited_list_pool_!= NULL){
				    delete visited_list_pool_;
				}	
                visited_list_pool_ = new VisitedListPool(1, max_elements_);				
			}
            
            {
		        std::unique_lock <std::mutex> lock(cur_element_count_guard_);
		
		        if (count0 >= max_elements_) {
                    throw std::runtime_error("The number of elements exceeds the specified limit");
                };
				
		    	cur_c = count0;
		    	count0++;
            }

            std::unique_lock <std::mutex> lock_el(link_list_locks_[cur_c]);
            int curlevel = getRandomLevel(mult_);
            if (level > 0)
                curlevel = level;

            element_levels_[cur_c] = curlevel;


            std::unique_lock <std::mutex> templock(global);
            int maxlevelcopy = maxlevel_;
            if (curlevel <= maxlevelcopy)
                templock.unlock();
            tableint currObj = enterpoint_node_;
            tableint enterpoint_copy = enterpoint_node_;

            memset(data_level0_memory_ + cur_c * size_data_per_element_, 0, size_data_per_element_);
			
			float temp_norm = 0;
			float* vec_;
			
			vec_ = (float*) data_point;
			for(int i = 0; i < vecdim; i++)
				temp_norm += vec_[i] * vec_[i];
             
			memcpy(getExternalLabeLp(cur_c), &label, sizeof(labeltype));
		    memcpy(getNormByInternalId2(cur_c), &temp_norm, sizeof(float));				
            memcpy(getDataByInternalId(cur_c), data_point, data_size_);	
                              
            if (curlevel) {
                linkLists_[cur_c] = (char *) malloc(size_links_per_element_ * curlevel + 1);
                if (linkLists_[cur_c] == nullptr)
                    throw std::runtime_error("Not enough memory: addPoint failed to allocate linklist");
                memset(linkLists_[cur_c], 0, size_links_per_element_ * curlevel + 1);
            }
			dist_t d;
            if ((signed)currObj != -1) {

                if (curlevel < maxlevelcopy) {
                    curdist = temp_norm +  getNormByInternalId(currObj) - 2 * fstdistfunc_(data_point, getDataByInternalId(currObj), dist_func_param_);					
					
                    for (int level = maxlevelcopy; level > curlevel; level--) {
                        bool changed = true;
                        while (changed) {
                            changed = false;
                            unsigned int *data;
                            std::unique_lock <std::mutex> lock(link_list_locks_[currObj]);
                            data = get_linklist(currObj,level);
                            int size = getListCount(data);

                            tableint *datal = (tableint *) (data + 1);
                            for (int i = 0; i < size; i++) {
                                tableint cand = datal[i];
                                if (cand < 0 || cand > max_elements_)
                                    throw std::runtime_error("cand error");
								
                                d = temp_norm +  getNormByInternalId(cand) - 2 * fstdistfunc_(data_point, getDataByInternalId(cand), dist_func_param_);

                                if (d < curdist) {
                                    curdist = d;
                                    currObj = cand;
                                    changed = true;
                                }
                            }
                        }
                    }
                }

				bool epDeleted = false;
				
                for (int level = std::min(curlevel, maxlevelcopy); level >= 0; level--) {
                    if (level > maxlevelcopy || level < 0)  // possible?
                        throw std::runtime_error("Level error");

                    std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> top_candidates = searchBaseLayer(
                            currObj, data_point, temp_norm, level);

                    mutuallyConnectNewElement(data_point, cur_c, top_candidates, level);

                    currObj = top_candidates.top().second;
                }


            } else {
                // Do nothing for the first element
                enterpoint_node_ = 0;
                maxlevel_ = curlevel;

            }

            //Releasing lock for the maximum level
            if (curlevel > maxlevelcopy) {
                enterpoint_node_ = cur_c;
                maxlevel_ = curlevel;
            }
            return cur_c;
        };

        float projdistfunc_(float* b, unsigned char* a, int X, float* book){	
	        float result = 0;
	        float diff0, diff1, diff2, diff3;
            const float* last = b + X;
            const float* unroll_group = last - 3;
            int c, d;
			
            /* Process 4 items with each loop for efficiency. */
            while (b < unroll_group) {
				c = a[0] + a[0];
				d = a[1] + a[1];
				
                diff0 = book[c] * b[0];
                diff1 = book[c + 1] * b[1];
                diff2 = book[d] * b[2];
                diff3 = book[d + 1] * b[3];
                result += diff0 + diff1 + diff2 + diff3;
                a += 2;
                b += 4;
            }
            return result;

        }

		void query_rot(int dim_, int qsize, float* massQ, float* R){
            float* data3 = new float[dim_];

            for(int i = 0; i < qsize; i++){		
	            for(int j = 0; j < dim_; j++){
		            data3[j] = fstdistfunc_( (const void*) (R + j * dim_), (const void*) (massQ + i * dim_), dist_func_param_);				        
	            }
                memcpy(massQ + i * dim_, data3, sizeof(float) * dim_);		
            }
		}

        void SearchWithOptGraph(float** book_, float* book2_, float* norm_book, const float *query, size_t K, size_t ef, 
            unsigned *indices, VisitedListPool *visited_list_pool_) {

            unsigned LL = ef;
            int Min_cand = 8;

            std::vector<Neighbor> retset(LL + 1);
            std::vector<Neighbor0> retset0(maxM0_ + 1);
  
            VisitedList *vl = visited_list_pool_->getFreeVisitedList();
            vl_type *visited_array = vl->mass;
            vl_type visited_array_tag = vl->curV; 
  
            tableint currObj = enterpoint_node_;
	        float* cur0 = (float *) getNormByInternalId2(enterpoint_node_);
	        float norm = *cur0;
	        cur0++;
            dist_t curdist = norm - 2 * fstdistfunc_((const void*)query, (const void*)cur0, dist_func_param_);

            for (int level = maxlevel_; level > 0; level--) {
                bool changed = true;
                while (changed) {
                    changed = false;
                    unsigned int *data;

                    data = (unsigned int *) get_linklist(currObj, level);
                    int size = getListCount(data);
                    tableint *datal = (tableint *) (data + 1);
                    for (int i = 0; i < size; i++) {
                        tableint cand = datal[i];
                        if (cand < 0 || cand > max_elements_)
                            throw std::runtime_error("cand error");
                 
	                    cur0 = (float *) getNormByInternalId2(cand);
	                    norm = *cur0;
	                    cur0++;
                        dist_t d = norm - 2 * fstdistfunc_((const void*)query, (const void*)cur0, dist_func_param_);				 

                        if (d < curdist) {
                            curdist = d;
                            currObj = cand;
                            changed = true;
                        }
                    }
                }
            }

            retset[0] = Neighbor(currObj, curdist, true, true);
            visited_array[currObj] = visited_array_tag;   	
  
            int k = 0;
            float* query_proj = new float[sub_dim];
            int l_num = 1;
            while (k < (int)LL) {
                int nk = LL;

                if(retset[k].flag) {
                    retset[k].flag = false;
                    unsigned n = retset[k].id;

	                _mm_prefetch(data_level0_memory_ + size_data_per_element_ * n, _MM_HINT_T0);   	  
	                unsigned *neighbors = (unsigned *)(data_level0_memory_ + size_data_per_element_ * n);
	  
                    unsigned MaxM = *neighbors;
                    neighbors++;
	  
	                bool fflag = true;
	                int sub_dim0 = sub_dim;

	                if(MaxM > 2){  
		                if(MaxM < sub_dim){ 
		                    if(MaxM % 2 == 0){sub_dim0 = MaxM;} 
		                    else{sub_dim0 = MaxM - 1;}
		                }

                        float* base_vec = (float* ) neighbors;      
                        neighbors += sub_dim;
	  
	                    unsigned char* neighbors5 = (unsigned char*) neighbors;
	                    unsigned char* neighbors2 = (unsigned char*) getVecByInternalId(n);
	  
	                    for(int i = 0; i < sub_dim0; i++){ 
	                        unsigned char* tmp_point = neighbors5;
	                        query_proj[i] = querydistfunc_(tmp_point, max_book, book_);   //change neighbors in function  
	   	                    query_proj[i] = query_proj[i] - base_vec[i];
	   	                    neighbors5 += max_book;
	                    }
      
	                    int X2 = sub_dim0 / 2;       
                        int cand_count = 0;
	  

                        int* data = (int*)get_linklist0(n);
                        tableint * datal = (tableint *) (data + 1);	   


	                    for(int i = 0; i < MaxM; i++){

                            if(visited_array[datal[i]] == visited_array_tag){
			                    neighbors2 += (X2+1);
			                    continue;
		                    }
	  
		                    float norm = norm_book[*neighbors2];
		                    neighbors2++;
		  
		                    unsigned char* tmp_point = neighbors2;
		                    float dist0 = projdistfunc_(query_proj, tmp_point, sub_dim0, book2_);
		  		  
		                    neighbors2 += X2;
		                    dist0 = norm * norm - 2 * norm * dist0;
		   	           			
		                    if(cand_count == 0)
		                        retset0[0] = Neighbor0(i, dist0);
		                    else{
			                    Neighbor0 nn0(i, dist0);
		                        int r = InsertIntoPool0(retset0.data(), cand_count, nn0);
		                    }
		  
		                    cand_count++;
	                    }
	  
	                    neighbors = (unsigned *) neighbors2;
	                    neighbors++;	
	  
	                    if(Min_cand < cand_count)
		                    MaxM = Min_cand; 
	                    else
		                    MaxM = cand_count;
	                }
	  
	                else{ fflag = false; }
	    
	                neighbors = (unsigned*) get_linklist0(n);
                    neighbors++;
	  
	                if(fflag == true){
                        for (unsigned m = 0; m < MaxM; ++m)
	                        _mm_prefetch(data_level0_memory_ + neighbors[ retset0[m].id ] * size_data_per_element_ + offsetNorm_, _MM_HINT_T0);
	                }
                    else{
		                for (unsigned m = 0; m < MaxM; ++m)
	                        _mm_prefetch(data_level0_memory_ + neighbors[m] * size_data_per_element_ + offsetNorm_, _MM_HINT_T0);
	                }	  
	                bool tflag = false;	 
                    int opp = 0;
					
                    for (unsigned m = 0; m < MaxM; ++m) {
		                unsigned id;
		                if(fflag == true){ 
                            id = neighbors[ retset0[m].id ];
                            visited_array[id] = visited_array_tag;
		                }
		                else{
			                id = neighbors[m];		
		                    if (visited_array[id] == visited_array_tag) continue;
                            visited_array[id] = visited_array_tag;		 
		                }
		
		                float *data = (float *)(data_level0_memory_ + id * size_data_per_element_ + offsetNorm_);
                        float norm = *data;
                        data++;
                        float dist = norm - 2 * fstdistfunc_( (const void*)query, (const void*)data, dist_func_param_);
        
		                int r;
		                if(l_num == LL){
			                if (dist >= retset[LL - 1].distance) {
			                    opp++;
			                    if(opp > 2) break;
			                    else continue;
			                }    	
		
                 		    Neighbor nn2(id, dist, true, true);
                            r = InsertIntoPool(retset.data(), LL, nn2);
		                }
	                 	else{
                            Neighbor nn(id, dist, true, true);
                            int r = InsertIntoPool(retset.data(), l_num, nn);
			                l_num++;
                        }

	                    if (r < nk) {nk = r;}
                    }
                }
				
                if (nk <= k)
                k = nk;
                else {++k;} 
            }
  
            for (size_t i = 0; i < K; i++) {
                indices[i] = getExternalLabel(retset[i].id);
            } 
            visited_list_pool_->releaseVisitedList(vl);
        }				
    };
}

